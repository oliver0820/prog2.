﻿namespace app
{


    partial class proyecto_finalDataSet
    {
    }
}

namespace app.proyecto_finalDataSetTableAdapters
{
    partial class UsuariosTableAdapter
    {
    }

    public partial class SP_BUSCARUSUARIOSTableAdapter {
    }
}

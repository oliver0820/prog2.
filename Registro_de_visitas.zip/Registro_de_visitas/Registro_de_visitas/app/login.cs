﻿using Capa_logica_de_negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace app
{
    public partial class login : Form
    {
        private readonly NegocioUsuario negocioUsuario = new NegocioUsuario();
        public login()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }


        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            registrar_usuario  RU= new registrar_usuario();
           RU.Show();

            this.Hide();
        }

        private bool EsAdministrador(string nombreUsuario, string contrasena)
        {
            bool esAdmin = false;

            // Realizar la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-JN6QEPA;Initial Catalog=proyecto_final;Integrated Security=True"))
            {
                // Definir la consulta SQL para verificar las credenciales del usuario y su tipo de usuario
                string query = "SELECT COUNT(*) FROM RegistroUsuario WHERE NombreUsuario = @NombreUsuario AND Contraseña = @Contraseña AND TipoUsuario = 'Administrador';";

                // Ejecutar la consulta
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agregar parámetros
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    command.Parameters.AddWithValue("@Contraseña", contrasena);

                    // Abrir la conexión
                    connection.Open();

                    // Ejecutar la consulta y obtener el resultado
                    int count = (int)command.ExecuteScalar();

                    // Verificar si se encontró un usuario administrador con las credenciales proporcionadas
                    if (count > 0)
                    {
                        esAdmin = true;
                    }
                }
            }

            return esAdmin;
        }


        private bool EsUsuario(string nombreUsuario, string contrasena)
        {
            bool esAdmin = false;

            // Realizar la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-JN6QEPA;Initial Catalog=proyecto_final;Integrated Security=True"))
            {
                // Definir la consulta SQL para verificar las credenciales del usuario y su tipo de usuario
                string query = "SELECT COUNT(*) FROM RegistroUsuario WHERE NombreUsuario = @NombreUsuario AND Contraseña = @Contraseña AND TipoUsuario = 'Administrador';";

                // Ejecutar la consulta
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agregar parámetros
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    command.Parameters.AddWithValue("@Contraseña", contrasena);

                    // Abrir la conexión
                    connection.Open();

                    // Ejecutar la consulta y obtener el resultado
                    int count = (int)command.ExecuteScalar();

                    // Verificar si se encontró un usuario administrador con las credenciales proporcionadas
                    if (count > 0)
                    {
                        esAdmin = true;
                    }
                }
            }

            return esAdmin;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            string nombreUsuario = txtNombreUsuario.Text;
            string contrasena = txtContrasena.Text;

            // Verificar si el usuario es un administrador
            if (negocioUsuario.EsAdmiinisrador(nombreUsuario, contrasena))
            {
                // Si el usuario es un administrador, se muestra el formulario fmreg y se oculta el formulario actual
                fmreg frm = new fmreg();
                frm.Show();
                this.Hide();
            }
            // Verificar si el usuario es un usuario normal
            else if (negocioUsuario.EsUsuario(nombreUsuario, contrasena))
            {
                // Si el usuario es un usuario normal, se muestra el formulario registro_basico y se oculta el formulario actual
                registro_basico RB = new registro_basico();
                RB.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Nombre de usuario o contraseña incorrectos.");
            }
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (txtNombreUsuario.Text.Trim() == "")
            {
                epError.SetError(txtNombreUsuario, "Introduzca su usuario existente...");
                txtNombreUsuario.Focus();
            }
            else
            {
                epError.Clear();
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (txtContrasena.Text.Trim() == "")
            {
                epError.SetError(txtContrasena, "Introduzca su contraseña existente...");
                txtContrasena.Focus();
            }
            else
            {
                epError.Clear();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

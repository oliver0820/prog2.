﻿using Capa_logica_de_negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace app
{
    public partial class registrar_usuario : Form
    {
        private readonly NegocioUsuario negocioUsuario = new NegocioUsuario();
        public registrar_usuario()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            login frm = new login();
            frm.Show();

            this.Hide();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {

            {
                string nombre = txtNombre.Text;
                string apellido = txtApellido.Text;
                string nombreUsuario = txtUsuario.Text;
                string contrasena  = txtContraseña.Text;
                string tipoUsuario = txtTipoUsuario.Text;

                if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(nombreUsuario) || string.IsNullOrEmpty(contrasena) || string.IsNullOrEmpty(tipoUsuario))
                {
                    MessageBox.Show("Por favor, complete todos los campos.");
                    return;
                }

                if (negocioUsuario.InsertarUsuario(nombre, apellido, nombreUsuario, contrasena, tipoUsuario))
                {
                    MessageBox.Show("Registro insertado correctamente.");
                }
                else
                {
                    MessageBox.Show("Error al insertar el registro.");
                }
            }
        }



        private void textBox3_Validated(object sender, EventArgs e)
        {
            if(txtUsuario.Text.Trim() == "")
            {
                epError.SetError(txtUsuario, "Introduzca el nombre...");
                txtUsuario.Focus();
            }
            else
            {
                epError.Clear();
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (txtApellido.Text.Trim() == "")
            {
                epError.SetError(txtApellido, "Introduzca el apellido...");
                txtApellido.Focus();
            }
            else
            {
                epError.Clear();
            }
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (txtNombre.Text.Trim() == "")
            {
                epError.SetError(txtNombre, "Introduzca la fecha de nacimiento...");
                txtNombre.Focus();
            }
            else
            {
                epError.Clear();
            }
        }

        private void textBox4_Validated(object sender, EventArgs e)
        {
            if (txtContraseña.Text.Trim() == "")
            {
                epError.SetError(txtContraseña, "Introduzca la contraseña...");
                txtContraseña.Focus();
            }
            else
            {
                epError.Clear();
            }
        }

        private void registrarus_Load(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtTipoUsuario_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using Capa_logica_de_negocio;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using app;
using System.Data.Common;


namespace app
{

    public partial class registro_basico : Form
    {
        private string idusuario;
        private bool Editarse = false;

        Entidad_USUARIO objEntidad = new Entidad_USUARIO();
        Negocios_USUARIO objNegocio = new Negocios_USUARIO();
        public registro_basico()
        {
            InitializeComponent();
        }



        private void registro_Load(object sender, EventArgs e)
        {
            // Configurar formato de DateTimePicker
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker1.ShowUpDown = true; // Muestra controles de subida/bajada para horas y minutos
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker1.ShowUpDown = true; // Muestra controles de subida/bajada para horas y minutos

            // Configurar formato de DateTimePicker2
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker2.ShowUpDown = true; // Muestra controles de subida/bajada para horas y minutos


            // Cargar datos en el formulario
            this.usuariosTableAdapter1.Fill(this.proyecto_finalDataSet.Usuarios);
        }

       

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (Editarse == false)
            {
                try
                {
                    objEntidad.Nombre = textNombre.Text.ToUpper();
                    objEntidad.Apellido = textApellido.Text.ToUpper();
                    objEntidad.Carrera = textCarrera.Text.ToUpper();
                    objEntidad.Correo = textCorreo.Text.ToUpper();
                    objEntidad.Edificio = comboBoxEdificio.Text.ToUpper();
                    objEntidad.Horase = dateTimePicker1.Value.ToString("dd/MM/yyyy hh:mm:ss");
                    objEntidad.Horass = dateTimePicker2.Value.ToString("dd/MM/yyyy hh:mm:ss");
                    objEntidad.Motivo = textMotivo.Text.ToUpper();
                    objEntidad.Aula = comboBoxAula.Text.ToUpper();

                    objNegocio.InsertandoUsuario(objEntidad);

                    MessageBox.Show("Registro guardado correctamente");

                    login ir_login = new login();
                    ir_login.Show();

                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo guardar el registro" + ex);
                }
            }


            if (Editarse == true)
            {
                try
                {
                    objEntidad.Idusuario = Convert.ToInt32(idusuario);
                    objEntidad.Nombre = textNombre.Text.ToUpper();
                    objEntidad.Apellido = textApellido.Text.ToUpper();
                    objEntidad.Carrera = textCarrera.Text.ToUpper();
                    objEntidad.Correo = textCorreo.Text.ToUpper();
                    objEntidad.Edificio = comboBoxEdificio.Text.ToUpper();
                    objEntidad.Horase = textHorase.Text.ToUpper();
                    objEntidad.Horass = textHorass.Text.ToUpper();
                    objEntidad.Motivo = textMotivo.Text.ToUpper();
                    objEntidad.Aula = comboBoxAula.Text.ToUpper();

                    objNegocio.InsertandoUsuario(objEntidad);

                    MessageBox.Show("Registro editado correctamente");
                    Editarse = false;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo editar el registro" + ex);
                }
            }
        }

       

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (tablaCategoria.SelectedRows.Count > 0)
            {
                Editarse = true;
                idusuario = tablaCategoria.CurrentRow.Cells[0].Value.ToString();
                textNombre.Text = tablaCategoria.CurrentRow.Cells[1].Value.ToString();
                textApellido.Text = tablaCategoria.CurrentRow.Cells[2].Value.ToString();
                textCarrera.Text = tablaCategoria.CurrentRow.Cells[3].Value.ToString();
                textCorreo.Text = tablaCategoria.CurrentRow.Cells[4].Value.ToString();
                comboBoxEdificio.Text = tablaCategoria.CurrentRow.Cells[5].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(tablaCategoria.CurrentRow.Cells[6].Value);
                dateTimePicker2.Value = Convert.ToDateTime(tablaCategoria.CurrentRow.Cells[7].Value);
                textMotivo.Text = tablaCategoria.CurrentRow.Cells[8].Value.ToString();
                comboBoxAula.Text = tablaCategoria.CurrentRow.Cells[9].Value.ToString();


            }
            else
            {
                MessageBox.Show("Por favor, seleccione la fila que desea editar");
            }
        }

        private void limpiarCaja()
        {
            Editarse = false;
            textNombre.Text = "";
            textApellido.Text = "";
            textCarrera.Text = "";
            textCorreo.Text = "";
            comboBoxEdificio.Text = "";
            textHorase.Text = "";
            textHorass.Text = "";
            textMotivo.Text = "";
            comboBoxAula.Text = "";
            textNombre.Focus();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            limpiarCaja();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            fmreg frm = new fmreg();
            frm.Show();

            this.Hide();
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            login ir_login = new login();
           ir_login.Show();

            this.Hide();
        }

        private void textCarrera_TextChanged(object sender, EventArgs e)
        {

        }

        private void textCarrera_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }



    


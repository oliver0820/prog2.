﻿using Capa_logica_de_negocio;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using app;
using System.Data.Common;


namespace app
{

    public partial class registro : Form
    {
        private string idusuario;
        private bool Editarse = false;

        Entidad_USUARIO objEntidad = new Entidad_USUARIO();
        Negocios_USUARIO objNegocio = new Negocios_USUARIO();
        public registro()
        {
            InitializeComponent();
        }
        private void registro_Load(object sender, EventArgs e)
        {
            // Configurar formato de DateTimePicker
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker1.ShowUpDown = true; // Muestra controles de subida/bajada para horas y minutos
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker1.ShowUpDown = true; // Muestra controles de subida/bajada para horas y minutos

            // Configurar formato de DateTimePicker2
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimePicker2.ShowUpDown = true; // Muestra controles de subida/bajada para horas y minutos


            // Cargar datos en el formulario
            this.usuariosTableAdapter1.Fill(this.proyecto_finalDataSet.Usuarios);
        }

        private void limpiarCaja()
        {
            Editarse = false;
            textNombre.Text = "";
            textApellido.Text = "";
            textCarrera.Text = "";
            textCorreo.Text = "";
            comboBoxEdificio.Text = "";
            textHorase.Text = "";
            textHorass.Text = "";
            textMotivo.Text = "";
            comboBoxAula.Text = "";
            textNombre.Focus();
        }


        private void ActualizarTabla()
        {
            // Actualiza los datos del adaptador
            this.usuariosTableAdapter1.Update(this.proyecto_finalDataSet.Usuarios);

            // Refresca el DataGridView para mostrar los cambios
            tablaCategoria.Refresh();
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!Editarse) // Si no se está editando
            {
                try
                {
                    // Llenar los datos del objeto entidad con los valores de los campos del formulario
                    objEntidad.Nombre = textNombre.Text.ToUpper();
                    objEntidad.Apellido = textApellido.Text.ToUpper();
                    objEntidad.Carrera = textCarrera.Text.ToUpper();
                    objEntidad.Correo = textCorreo.Text.ToUpper();
                    objEntidad.Edificio = comboBoxEdificio.Text.ToUpper();
                    objEntidad.Horase = dateTimePicker1.Value.ToString("dd/MM/yyyy hh:mm:ss");
                    objEntidad.Horass = dateTimePicker2.Value.ToString("dd/MM/yyyy hh:mm:ss");
                    objEntidad.Motivo = textMotivo.Text.ToUpper();
                    objEntidad.Aula = comboBoxAula.Text.ToUpper();

                    // Llamar al método de la capa lógica de negocio para insertar el usuario
                    objNegocio.InsertandoUsuario(objEntidad);

                    MessageBox.Show("Registro guardado correctamente");

                    // Limpiar los campos del formulario
                    limpiarCaja();
                    // Actualizar la tabla
                    ActualizarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo guardar el registro" + ex);
                }
            }
            else // Si se está editando
            {
                try
                {
                    // Llenar los datos del objeto entidad con los valores de los campos del formulario
                    objEntidad.Idusuario = Convert.ToInt32(idusuario);
                    objEntidad.Nombre = textNombre.Text.ToUpper();
                    objEntidad.Apellido = textApellido.Text.ToUpper();
                    objEntidad.Carrera = textCarrera.Text.ToUpper();
                    objEntidad.Correo = textCorreo.Text.ToUpper();
                    objEntidad.Edificio = comboBoxEdificio.Text.ToUpper();
                    objEntidad.Horase = dateTimePicker1.Value.ToString("dd/MM/yyyy hh:mm:ss");
                    objEntidad.Horass = dateTimePicker2.Value.ToString("dd/MM/yyyy hh:mm:ss");
                    objEntidad.Motivo = textMotivo.Text.ToUpper();
                    objEntidad.Aula = comboBoxAula.Text.ToUpper();

                    // Llamar al método de la capa lógica de negocio para editar el usuario
                    objNegocio.EditandoCategoria(objEntidad);


                    MessageBox.Show("Registro editado correctamente");
                    // Reiniciar la variable de edición
                    Editarse = false;
                    // Actualizar la tabla
                    ActualizarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo editar el registro" + ex);
                }
            }
        }




        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (tablaCategoria.SelectedRows.Count > 0)
            {
                // Obtener la fila seleccionada
                DataGridViewRow filaSeleccionada = tablaCategoria.SelectedRows[0];

                // Actualizar los valores de la fila seleccionada con los valores de los TextBox y otros controles
                filaSeleccionada.Cells[1].Value = textNombre.Text.ToUpper();
                filaSeleccionada.Cells[2].Value = textApellido.Text.ToUpper();
                filaSeleccionada.Cells[3].Value = textCarrera.Text.ToUpper();
                filaSeleccionada.Cells[4].Value = textCorreo.Text.ToUpper();
                filaSeleccionada.Cells[5].Value = comboBoxEdificio.Text.ToUpper();
                filaSeleccionada.Cells[6].Value = dateTimePicker1.Value.ToString("dd/MM/yyyy hh:mm:ss");
                filaSeleccionada.Cells[7].Value = dateTimePicker2.Value.ToString("dd/MM/yyyy hh:mm:ss");
                filaSeleccionada.Cells[8].Value = textMotivo.Text.ToUpper();
                filaSeleccionada.Cells[9].Value = comboBoxAula.Text.ToUpper();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione la fila que desea editar");
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            fmreg frm = new fmreg();
            frm.Show();

            this.Hide();
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            fmreg frm = new fmreg();
            frm.Show();

            this.Hide();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void tablaCategoria_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox_carreras_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textCarrera_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxEdificio_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton_Eliminar_Click(object sender, EventArgs e)
        {
            if (tablaCategoria.SelectedRows.Count > 0)
            {
                // Mostrar un mensaje de confirmación antes de eliminar
                DialogResult resultado = MessageBox.Show("¿Estás seguro de que quieres eliminar este registro?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    // Obtener la fila seleccionada y eliminarla de la tabla
                    tablaCategoria.Rows.Remove(tablaCategoria.SelectedRows[0]);
                    MessageBox.Show("El registro ha sido eliminado correctamente", "Registro Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Por favor, seleccione la fila que desea eliminar", "Selección requerida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}



    


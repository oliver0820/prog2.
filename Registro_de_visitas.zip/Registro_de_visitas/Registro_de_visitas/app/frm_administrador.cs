﻿using Capa_logica_de_negocio;
using CapaEntidad;
using System;
using System.Windows.Forms;




namespace app
{
    public partial class fmreg : Form
    {
        private string idusuario;
        private bool Editarse = false;

        Entidad_USUARIO objEntidad = new Entidad_USUARIO();
        Negocios_USUARIO objNegocio = new Negocios_USUARIO();
        public fmreg()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

        }

        private void frmCategorias_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'proyecto_finalDataSet.Usuarios' Puede moverla o quitarla según sea necesario.
            this.usuariosTableAdapter.Fill(this.proyecto_finalDataSet.Usuarios);
          
            mostrarBuscarTabla("");
           
            accionesTabla();
        }
        public void accionesTabla()
        {
            tablaUsuarios.Columns[0].Visible = false;
            tablaUsuarios.ClearSelection();

        }
        /*para buscar edificio*/
        public void mostrarBuscarTabla(string buscar)
        {
            Negocios_USUARIO objNegocio = new Negocios_USUARIO();
            tablaUsuarios.DataSource = objNegocio.ListarEdificio(buscar);
        }
            private void txtBuscar_SelectedIndexChanged(object sender, EventArgs e)
            {

            mostrarBuscarTabla(txtBuscar_E.Text);
            }
        /*para buscar Usuario*/
        public void mostrarBuscar_Usuario(string buscar)
        {
            Negocios_USUARIO objNegocio = new Negocios_USUARIO();
            tablaUsuarios.DataSource = objNegocio.ListarUsuario(buscar);
        }
        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            mostrarBuscar_Usuario(txtBuscar_U.Text);

        }

  



        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textDescripcion_TextChanged(object sender, EventArgs e)
        {

        }

        private void textApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void tablaCategoria_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            registro frm = new registro();
            frm.ShowDialog();

            this.Hide();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            registro frm = new registro();
            frm.Show();

            this.Hide();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            login frm = new login();
            frm.Show();

            this.Hide();

        }

        private void topFormulario_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using CapaEntidad;
using System.Data;

namespace Capa_Datos
{
    public class Datos_USUARIO
    {
        SqlConnection conexion = new SqlConnection(@"Data Source=DESKTOP-JN6QEPA;Initial Catalog=proyecto_final;Integrated Security=True");

        public List <Entidad_USUARIO>ListarUsuarios(string buscar)
        {
            SqlDataReader LeerFilas;
            SqlCommand cnd = new SqlCommand("SP_BUSCARUSUARIOS", conexion);
            cnd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cnd.Parameters.AddWithValue("@BUSCAR", buscar);
            LeerFilas = cnd.ExecuteReader();

            List<Entidad_USUARIO> Listar = new List<Entidad_USUARIO>();
            while(LeerFilas.Read())
            {
                Listar.Add(new Entidad_USUARIO
                {
                    Idusuario = LeerFilas.GetInt32(0),
                    Nombre = LeerFilas.GetString(1),
                    Apellido = LeerFilas.GetString(2),
                    Carrera = LeerFilas.GetString(3),
                    Correo = LeerFilas.GetString(4),
                    Edificio= LeerFilas.GetString(5),
                    Horase = LeerFilas.GetString(6),
                    Horass = LeerFilas.GetString(7),
                    Motivo = LeerFilas.GetString(8),
                    Aula = LeerFilas.GetString(9)

                })  ;
            }
            conexion.Close();
            LeerFilas.Close();
            return Listar;
        }

        public List<Entidad_USUARIO> ListarEdificio(string buscar)
        {
            SqlDataReader LeerFilas;
            SqlCommand cnd = new SqlCommand("SP_BUSCAREDIFICIO", conexion);
            cnd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cnd.Parameters.AddWithValue("@BUSCAR", buscar);
            LeerFilas = cnd.ExecuteReader();

            List<Entidad_USUARIO> Listar = new List<Entidad_USUARIO>();
            while (LeerFilas.Read())
            {
                Listar.Add(new Entidad_USUARIO
                {
                    Idusuario = LeerFilas.GetInt32(0),
                    Nombre = LeerFilas.GetString(1),
                    Apellido = LeerFilas.GetString(2),
                    Carrera = LeerFilas.GetString(3),
                    Correo = LeerFilas.GetString(4),
                    Edificio = LeerFilas.GetString(5),
                    Horase = LeerFilas.GetString(6),
                    Horass = LeerFilas.GetString(7),
                    Motivo = LeerFilas.GetString(8),
                    Aula = LeerFilas.GetString(9)

                });
            }
            conexion.Close();
            LeerFilas.Close();
            return Listar;
        }



        public void InsertarUsuario(Entidad_USUARIO Usuario)
        {
            SqlCommand cnd = new SqlCommand("SP_INSERTARUSUARIOS", conexion);
            cnd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            
            cnd.Parameters.AddWithValue("@NOMBRE", Usuario.Nombre);
            cnd.Parameters.AddWithValue("@APELLIDO", Usuario.Apellido);
            cnd.Parameters.AddWithValue("CARRERA", Usuario.Carrera);
            cnd.Parameters.AddWithValue("@CORREO", Usuario.Correo);
            cnd.Parameters.AddWithValue("@EDIFICIO", Usuario.Edificio);
            cnd.Parameters.AddWithValue("@HORASE", Usuario.Horase);
            cnd.Parameters.AddWithValue("@HORASS", Usuario.Horass);
            cnd.Parameters.AddWithValue("@MOTIVO", Usuario.Motivo);
            cnd.Parameters.AddWithValue("@AULA", Usuario.Aula);

            cnd.ExecuteNonQuery();
            conexion.Close();

        }
        public void EditarUsuario(Entidad_USUARIO Usuario)
        {
            SqlCommand cnd = new SqlCommand("SP_EDITARUSUARIOS", conexion);
            cnd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cnd.Parameters.AddWithValue("@IDUSUARIO", Usuario.Idusuario);
            cnd.Parameters.AddWithValue("@NOMBRE", Usuario.Nombre);
            cnd.Parameters.AddWithValue("@APELLIDO", Usuario.Apellido);
            cnd.Parameters.AddWithValue("CARRERA", Usuario.Carrera);
            cnd.Parameters.AddWithValue("@CORREO", Usuario.Correo);
            cnd.Parameters.AddWithValue("@EDIFICIO", Usuario.Edificio);
            cnd.Parameters.AddWithValue("@HORASE", Usuario.Horase);
            cnd.Parameters.AddWithValue("@HORASS", Usuario.Horass);
            cnd.Parameters.AddWithValue("@MOTIVO", Usuario.Motivo);
            cnd.Parameters.AddWithValue("@AULA", Usuario.Aula);

            cnd.ExecuteNonQuery();
            conexion.Close();
        }
        
        public void EliminarUsuario(Entidad_USUARIO Usuario)
        {
            SqlCommand cnd = new SqlCommand("SP_ELIMINARUSUARIOS", conexion);
            cnd.CommandType = CommandType.StoredProcedure;
            conexion.Open();

            cnd.Parameters.AddWithValue("@IDUSUARIO", Usuario.Idusuario);
            cnd.ExecuteNonQuery();
            conexion.Close();

            
        }


    }

    // Clase de datos para usuarios
    public class DatosUsuario
    {
        private readonly string cadenaConexion = @"Data Source=DESKTOP-JN6QEPA;Initial Catalog=proyecto_final;Integrated Security=True";

        public bool InsertarUsuario(string nombre, string apellido, string nombreUsuario, string contrasena, string tipoUsuario)
        {
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    string consulta = "INSERT INTO RegistroUsuario (Nombre, Apellido, NombreUsuario, Contraseña, TipoUsuario) VALUES (@Nombre, @Apellido, @NombreUsuario, @Contraseña, @TipoUsuario)";

                    using (SqlCommand comando = new SqlCommand(consulta, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", nombre);
                        comando.Parameters.AddWithValue("@Apellido", apellido);
                        comando.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                        comando.Parameters.AddWithValue("@Contraseña", contrasena);
                        comando.Parameters.AddWithValue("@TipoUsuario", tipoUsuario);

                        conexion.Open();
                        int filasAfectadas = comando.ExecuteNonQuery();
                        return filasAfectadas > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // Registrar el error en un archivo de registro o en la base de datos de registro de errores
                Console.WriteLine("Error al insertar usuario: " + ex.Message);
                return false;
            }
        }


        public bool EsAdministrador(string nombreUsuario, string contrasena)
        {
            bool esAdmin = false;

            // Realizar la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-JN6QEPA;Initial Catalog=proyecto_final;Integrated Security=True"))
            {
                // Definir la consulta SQL para verificar las credenciales del usuario y su tipo de usuario
                string query = "SELECT COUNT(*) FROM RegistroUsuario WHERE NombreUsuario = @NombreUsuario AND Contraseña = @Contraseña AND TipoUsuario = 'Administrador';";

                // Ejecutar la consulta
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agregar parámetros
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    command.Parameters.AddWithValue("@Contraseña", contrasena);

                    // Abrir la conexión
                    connection.Open();

                    // Ejecutar la consulta y obtener el resultado
                    int count = (int)command.ExecuteScalar();

                    // Verificar si se encontró un usuario administrador con las credenciales proporcionadas
                    if (count > 0)
                    {
                        esAdmin = true;
                    }
                }
            }

            return esAdmin;
        }


        public bool EsUsuario(string nombreUsuario, string contrasena)
        {
            bool esAdmin = false;

            // Realizar la conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-JN6QEPA;Initial Catalog=proyecto_final;Integrated Security=True"))
            {
                // Definir la consulta SQL para verificar las credenciales del usuario y su tipo de usuario
                string query = "SELECT COUNT(*) FROM RegistroUsuario WHERE NombreUsuario = @NombreUsuario AND Contraseña = @Contraseña AND TipoUsuario = 'Usuario';";

                // Ejecutar la consulta
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agregar parámetros
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
                    command.Parameters.AddWithValue("@Contraseña", contrasena);

                    // Abrir la conexión
                    connection.Open();

                    // Ejecutar la consulta y obtener el resultado
                    int count = (int)command.ExecuteScalar();

                    // Verificar si se encontró un usuario con las credenciales proporcionadas
                    if (count > 0)
                    {
                        esAdmin = true;
                    }
                }
            }

            return esAdmin;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using Capa_Datos;

namespace Capa_logica_de_negocio
{
    public class Negocios_USUARIO
    {
        Datos_USUARIO objDato = new Datos_USUARIO();
        public List<Entidad_USUARIO> ListarUsuario(string buscar)
        {
            return objDato.ListarUsuarios(buscar);
        }

        public List<Entidad_USUARIO> ListarEdificio(string buscar)
        {
            return objDato.ListarEdificio(buscar);
        }
        public void InsertandoUsuario(Entidad_USUARIO Categoria)
        {
            objDato.InsertarUsuario(Categoria);
        }
        public void EditandoCategoria(Entidad_USUARIO Categoria)
        {
            objDato.EditarUsuario(Categoria);
        }
        public void EliminandoUsuario(Entidad_USUARIO Categoria)
        {
            objDato.EliminarUsuario(Categoria);
        }

       


    }

    // Clase de negocios para usuarios
    public class NegocioUsuario
    {
        
        private readonly DatosUsuario datosUsuario = new DatosUsuario();

        public bool InsertarUsuario(string nombre, string apellido, string nombreUsuario, string contraseña, string tipoUsuario)
        {
            // Aquí podrías agregar lógica de validación adicional si es necesario
            return datosUsuario.InsertarUsuario(nombre, apellido, nombreUsuario, contraseña, tipoUsuario);
        }

        public bool EsUsuario(string nombreUsuario, string contrasena)
        {
            return datosUsuario.EsUsuario(nombreUsuario, contrasena);
        }
        public bool EsAdmiinisrador(string nombreUsuario, string contrasena)
        {
            return datosUsuario.EsAdministrador(nombreUsuario, contrasena);
        }
    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SistemaControlAutobuses.Data;

namespace SistemaControlAutobuses.Business
{
    public class ViajeManager
    {

        private DataAccess dataAccess;

        public ViajeManager()
        {
            dataAccess = new DataAccess(); // Instancia del acceso a datos
        }



        //

        // Método para verificar si un chofer está disponible
        private bool EsChoferDisponible(int idChofer)
        {
            // Lógica para verificar la disponibilidad del chofer
            // Puedes implementar la lógica necesaria aquí, por ejemplo, consultando la base de datos
            // y comprobando si el chofer tiene asignado algún viaje en el momento actual
            return true; // Placeholder, implementar la lógica real
        }

        // Método para verificar si un autobús está disponible
        private bool EsAutobusDisponible(int idAutobus)
        {
            // Lógica para verificar la disponibilidad del autobús
            // Similar a EsChoferDisponible(), implementar la lógica necesaria
            return true; // Placeholder, implementar la lógica real
        }

        // Método para verificar si una ruta está disponible
        private bool EsRutaDisponible(int idRuta)
        {
            // Lógica para verificar la disponibilidad de la ruta
            // Similar a EsChoferDisponible(), implementar la lógica necesaria
            return true; // Placeholder, implementar la lógica real
        }
    }
}
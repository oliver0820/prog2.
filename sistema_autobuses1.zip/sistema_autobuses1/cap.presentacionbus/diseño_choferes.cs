﻿using SistemaControlAutobuses.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace cap.presentacionbus
{
    public partial class diseño_choferes : Form
    {
        public diseño_choferes()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void diseño_choferes_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet1.Choferes' Puede moverla o quitarla según sea necesario.
            this.choferesTableAdapter.Fill(this.sistemaAutobusesDataSet1.Choferes);

        }

        private void ActualizarDataGridViewchoferes()
        {
            // Obtener los datos actualizados de la base de datos
            DataAccess dataAccess = new DataAccess();
            DataTable choferesDataTable = dataAccess.ListarChoferes();

            // Asignar los datos al DataGridView
            dataGridView1.DataSource = choferesDataTable;
        }


        private void LimpiarCamposchoferes()
        {
            // Limpiar los campos de texto
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            // Obtener los valores ingresados en los TextBoxes y DateTimePicker
            string nombre = textBox1.Text;
            string apellido = textBox4.Text;
            DateTime fechaNacimiento = dateTimePicker1.Value;
            string cedula = textBox2.Text;

            // Llamar al método de la capa de datos para insertar el chofer
            DataAccess dataAccess = new DataAccess();
            dataAccess.InsertarChofer(nombre, apellido, fechaNacimiento, cedula);

            // Limpiar los campos después de guardar
           

            LimpiarCamposchoferes();

            ActualizarDataGridViewchoferes();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Obtener el valor del ID del chofer de la fila seleccionada
                int idChofer = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Id"].Value);

                // Llamar al método de la capa de datos para eliminar el chofer
                DataAccess dataAccess = new DataAccess();
                dataAccess.EliminarChofer(idChofer);

                // Actualizar el DataGridView después de la eliminación
                ActualizarDataGridViewchoferes();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Obtener el ID del chofer seleccionado
                int idChofer = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Id"].Value); // Asegúrate de que el nombre de la columna sea correcto

                // Obtener los nuevos valores ingresados en los TextBoxes
                string nuevoNombre = textBox1.Text;
                string nuevoApellido = textBox4.Text;
                DateTime nuevaFechaNacimiento = dateTimePicker1.Value; // Ajusta según el control utilizado para la fecha
                string nuevaCedula = textBox2.Text;

                // Llamar al método de la capa de datos para editar el chofer
                DataAccess dataAccess = new DataAccess();
                dataAccess.EditarChofer(idChofer, nuevoNombre, nuevoApellido, nuevaFechaNacimiento, nuevaCedula);


                LimpiarCamposchoferes();

                ActualizarDataGridViewchoferes();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila para editar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
           

            }
        }
    }
}

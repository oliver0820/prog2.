﻿using SistemaControlAutobuses.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static cap.presentacionbus.SistemaAutobusesDataSet9;

namespace cap.presentacionbus
{
    public partial class interfaz_Viajes : Form
    {
        public interfaz_Viajes()
        {
            InitializeComponent();
        }

        private void interfaz_Viajes_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet9.ViajesConDescripciones3' Puede moverla o quitarla según sea necesario.
            this.viajesConDescripciones3TableAdapter.Fill(this.sistemaAutobusesDataSet9.ViajesConDescripciones3);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet7.ViajesDisponibles' Puede moverla o quitarla según sea necesario.
            this.viajesDisponiblesTableAdapter.Fill(this.sistemaAutobusesDataSet7.ViajesDisponibles);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet6.RutasDisponibles' Puede moverla o quitarla según sea necesario.
            this.rutasDisponiblesTableAdapter.Fill(this.sistemaAutobusesDataSet6.RutasDisponibles);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet6.AutobusesDisponibles' Puede moverla o quitarla según sea necesario.
            this.autobusesDisponiblesTableAdapter.Fill(this.sistemaAutobusesDataSet6.AutobusesDisponibles);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet6.ChoferesDisponibles' Puede moverla o quitarla según sea necesario.
            this.choferesDisponiblesTableAdapter.Fill(this.sistemaAutobusesDataSet6.ChoferesDisponibles);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet2.Rutas' Puede moverla o quitarla según sea necesario.
            this.rutasTableAdapter.Fill(this.sistemaAutobusesDataSet2.Rutas);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet1.Choferes' Puede moverla o quitarla según sea necesario.
            this.choferesTableAdapter.Fill(this.sistemaAutobusesDataSet1.Choferes);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet.Autobuses' Puede moverla o quitarla según sea necesario.
            this.autobusesTableAdapter.Fill(this.sistemaAutobusesDataSet.Autobuses);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet3.Viajes' Puede moverla o quitarla según sea necesario.
            this.viajesTableAdapter.Fill(this.sistemaAutobusesDataSet3.Viajes);

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        private void LimpiarCamposViajes()
        {
            // Limpiar los valores de los ComboBox después de guardar los datos
            comboBox1.SelectedIndex = -1; // Desselecciona cualquier elemento seleccionado
            comboBox2.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;
        }

        private void ActualizarDataGridViewviajes()
        {
            try
            {
                // Llamar al método de la capa de datos para obtener los datos para el DataGridView2
                DataAccess dataAccess = new DataAccess();
                DataTable ViajesDataTable = dataAccess.ListarViajes();

                // Asignar el DataTable como origen de datos del DataGridView2
                dataGridView2.DataSource = ViajesDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el DataGridView2: " + ex.Message);
            }
        }
        private void ActualizarDataGridViewviajes2()
        {
            try
            {
                // Llamar al método de la capa de datos para obtener los datos para el DataGridView2
                DataAccess dataAccess = new DataAccess();
                DataTable ViajesConDescripciones3 = dataAccess.ObtenerViajesConDescripciones3();

                // Asignar el DataTable como origen de datos del DataGridView2
                dataGridView2.DataSource = ViajesConDescripciones3;
                ;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el DataGridView2: " + ex.Message);
            }
        }





        private void pictureBox1_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores ingresados en los TextBoxes
                int choferId = int.Parse(comboBox1.Text);
                int autobusId = int.Parse(comboBox2.Text);
                int rutaId = int.Parse(comboBox3.Text);

                // Llamar al método de la capa de datos para insertar el viaje
                DataAccess dataAccess = new DataAccess();
                dataAccess.EditarViaje(choferId, autobusId, rutaId);

                // Mostrar mensaje de éxito
                MessageBox.Show("El viaje se ha guardado correctamente.");

                // Limpiar los campos de texto
                LimpiarCamposViajes();
                ActualizarDataGridViewviajes();
                ActualizarDataGridViewviajes2();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el viaje: " + ex.Message);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
                // Verificar si hay al menos una fila seleccionada
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Obtener el ID del viaje desde la fila seleccionada
                    int idViaje = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Id"].Value);

                    // Obtener los nuevos valores seleccionados en los ComboBox
                    int nuevoChoferId = Convert.ToInt32(comboBox1.SelectedValue);
                    int nuevoAutobusId = Convert.ToInt32(comboBox2.SelectedValue);
                    int nuevoRutaId = Convert.ToInt32(comboBox3.SelectedValue);

                    // Llamar al método de la capa de datos para actualizar el viaje
                    DataAccess dataAccess = new DataAccess();
                    dataAccess.EditarViaje(idViaje, nuevoChoferId, nuevoAutobusId, nuevoRutaId);

                    LimpiarCamposViajes();
                    ActualizarDataGridViewviajes();
                    ActualizarDataGridViewviajes2();

                    // Mostrar mensaje de éxito
                    MessageBox.Show("El viaje se ha actualizado correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el viaje: " + ex.Message);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            try
            {
                // Verificar si hay al menos una fila seleccionada
                if (dataGridView2.SelectedRows.Count > 0)
                {
                    // Obtener el ID del viaje desde la fila seleccionada
                    int idViaje = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Id"].Value);

                    // Llamar al método de la capa de datos para eliminar el viaje
                    DataAccess dataAccess = new DataAccess();
                    dataAccess.EliminarViaje(idViaje);

                    // Actualizar el DataGridView para reflejar los cambios
                    LimpiarCamposViajes();
                    ActualizarDataGridViewviajes();
                    ActualizarDataGridViewviajes2();

                    // Mostrar mensaje de éxito
                    MessageBox.Show("El viaje se ha eliminado correctamente.");
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione una fila para eliminar el viaje.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el viaje: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
    
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace cap.presentacionbus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario diseño_rutas
            diseño_rutas formDiseñoRutas = new diseño_rutas();

            // Muestra el formulario de manera modal
            formDiseñoRutas.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario diseño_buses
            diseño_buses formDiseñoBuses = new diseño_buses();

            // Muestra el formulario
            formDiseñoBuses.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Crea una instancia del formulario diseño_choferes
            diseño_choferes formDiseñoChoferes = new diseño_choferes();

            // Muestra el formulario
            formDiseñoChoferes.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            interfaz_Viajes forminterfaz_Viajes = new interfaz_Viajes();

            // Muestra el formulario
            forminterfaz_Viajes.Show(); 
        }
    }
}

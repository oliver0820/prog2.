﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaControlAutobuses.Data;

namespace cap.presentacionbus
{
    public partial class diseño_buses : Form
    {
        public diseño_buses()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet4.Choferes' Puede moverla o quitarla según sea necesario.
            this.choferesTableAdapter.Fill(this.sistemaAutobusesDataSet4.Choferes);
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet.Autobuses' Puede moverla o quitarla según sea necesario.
            this.autobusesTableAdapter.Fill(this.sistemaAutobusesDataSet.Autobuses);

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
 private void ActualizarDataGridView()
        {
            // Obtener los datos actualizados de la base de datos
            DataAccess dataAccess = new DataAccess();
            DataTable autobusesDataTable = dataAccess.ListarAutobuses();

            // Asignar los datos al DataGridView
            dataGridView2.DataSource = autobusesDataTable;
        }

        private void LimpiarCampos()
        {
            // Limpiar los campos de texto
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }
        private void button4_SizeChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            // Obtener los valores ingresados en los TextBoxes
            string marca = textBox1.Text;
            string modelo = textBox4.Text; // No especificaste dónde se ingresa el modelo, asumo que es textBox4
            string placa = textBox3.Text;
            string color = textBox2.Text;
            int Año = int.Parse(textBox5.Text);

            // Llamar al método de la capa de datos para insertar el autobús
            DataAccess dataAccess = new DataAccess();
            dataAccess.InsertarAutobus(marca, modelo, placa, color, Año);

            // Actualizar el DataGridView
            ActualizarDataGridView();

            // Limpiar los campos de texto
            LimpiarCampos();

        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Obtener el valor del ID del autobús de la fila seleccionada
                int idAutobus = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Id"].Value);

                // Llamar al método de la capa de datos para eliminar el autobús
                DataAccess dataAccess = new DataAccess();
                dataAccess.EliminarAutobus(idAutobus);

                
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Actualizar el DataGridView
            ActualizarDataGridView();

            // Limpiar los campos de texto
            LimpiarCampos();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Obtener el ID del autobús seleccionado
                int idAutobus = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Id"].Value); // Asegúrate de que el nombre de la columna sea correcto

                // Obtener los nuevos valores ingresados en los TextBoxes
                string nuevaMarca = textBox1.Text;
                string nuevoModelo = textBox4.Text;
                string nuevaPlaca = textBox3.Text;
                string nuevoColor = textBox2.Text;
                int nuevoAño = int.Parse(textBox5.Text);

                // Llamar al método de la capa de datos para editar el autobús
                DataAccess dataAccess = new DataAccess();
                dataAccess.EditarAutobus(idAutobus, nuevaMarca, nuevoModelo, nuevaPlaca, nuevoColor, nuevoAño);

                // Actualizar el DataGridView
                ActualizarDataGridView();

                // Limpiar los campos de texto después de editar
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila para editar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}

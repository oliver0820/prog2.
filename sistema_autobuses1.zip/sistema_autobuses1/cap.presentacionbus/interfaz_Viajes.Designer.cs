﻿namespace cap.presentacionbus
{
    partial class interfaz_Viajes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(interfaz_Viajes));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this._SistemaAutobuses_DataSet1 = new cap.presentacionbus._SistemaAutobuses_DataSet1();
            this.sistemaAutobusesDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sistemaAutobusesDataSet3 = new cap.presentacionbus.SistemaAutobusesDataSet3();
            this.viajesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viajesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet3TableAdapters.ViajesTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.sistemaAutobusesDataSet = new cap.presentacionbus.SistemaAutobusesDataSet();
            this.autobusesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.autobusesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSetTableAdapters.AutobusesTableAdapter();
            this.autobusesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sistemaAutobusesDataSet1 = new cap.presentacionbus.SistemaAutobusesDataSet1();
            this.choferesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.choferesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet1TableAdapters.ChoferesTableAdapter();
            this.sistemaAutobusesDataSet2 = new cap.presentacionbus.SistemaAutobusesDataSet2();
            this.rutasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rutasTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet2TableAdapters.RutasTableAdapter();
            this.sistemaAutobusesDataSet6 = new cap.presentacionbus.SistemaAutobusesDataSet6();
            this.choferesDisponiblesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.choferesDisponiblesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet6TableAdapters.ChoferesDisponiblesTableAdapter();
            this.autobusesDisponiblesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.autobusesDisponiblesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet6TableAdapters.AutobusesDisponiblesTableAdapter();
            this.autobusesDisponiblesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rutasDisponiblesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rutasDisponiblesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet6TableAdapters.RutasDisponiblesTableAdapter();
            this.rutasDisponiblesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sistemaAutobusesDataSet7 = new cap.presentacionbus.SistemaAutobusesDataSet7();
            this.viajesDisponiblesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viajesDisponiblesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet7TableAdapters.ViajesDisponiblesTableAdapter();
            this.sistemaAutobusesDataSet8 = new cap.presentacionbus.SistemaAutobusesDataSet8();
            this.insertarViajeConDescripcionesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.insertarViajeConDescripcionesTableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet8TableAdapters.InsertarViajeConDescripcionesTableAdapter();
            this.sistemaAutobusesDataSet9 = new cap.presentacionbus.SistemaAutobusesDataSet9();
            this.viajesConDescripciones3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viajesConDescripciones3TableAdapter = new cap.presentacionbus.SistemaAutobusesDataSet9TableAdapters.ViajesConDescripciones3TableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.viajeIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choferIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreChoferDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoChoferDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.autobusIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.marcaAutobusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rutaIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreRutaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rutaIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.autobusIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.choferIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._SistemaAutobuses_DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viajesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.choferesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rutasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.choferesDisponiblesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesDisponiblesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesDisponiblesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rutasDisponiblesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rutasDisponiblesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viajesDisponiblesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.insertarViajeConDescripcionesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viajesConDescripciones3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.ErrorImage")));
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.InitialImage")));
            this.pictureBox4.Location = new System.Drawing.Point(139, 20);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(62, 39);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 34;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(234, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(62, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 33;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(49, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(62, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 24);
            this.label3.TabIndex = 24;
            this.label3.Text = "ID_AUTOBUS :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 24);
            this.label2.TabIndex = 23;
            this.label2.Text = "ID_RUTA :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "ID_CHOFER :";
            // 
            // pictureBox3
            // 
            this.pictureBox3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.ErrorImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(586, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(215, 56);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // _SistemaAutobuses_DataSet1
            // 
            this._SistemaAutobuses_DataSet1.DataSetName = "_SistemaAutobuses_DataSet1";
            this._SistemaAutobuses_DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sistemaAutobusesDataSet1BindingSource
            // 
            this.sistemaAutobusesDataSet1BindingSource.DataSource = this._SistemaAutobuses_DataSet1;
            this.sistemaAutobusesDataSet1BindingSource.Position = 0;
            // 
            // sistemaAutobusesDataSet3
            // 
            this.sistemaAutobusesDataSet3.DataSetName = "SistemaAutobusesDataSet3";
            this.sistemaAutobusesDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // viajesBindingSource
            // 
            this.viajesBindingSource.DataMember = "Viajes";
            this.viajesBindingSource.DataSource = this.sistemaAutobusesDataSet3;
            // 
            // viajesTableAdapter
            // 
            this.viajesTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.choferesDisponiblesBindingSource, "Id", true));
            this.comboBox1.DataSource = this.choferesDisponiblesBindingSource;
            this.comboBox1.DisplayMember = "Id";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(184, 98);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 35;
            this.comboBox1.ValueMember = "Id";
            // 
            // comboBox2
            // 
            this.comboBox2.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.autobusesDisponiblesBindingSource1, "Id", true));
            this.comboBox2.DataSource = this.autobusesDisponiblesBindingSource;
            this.comboBox2.DisplayMember = "Id";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(184, 136);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 36;
            this.comboBox2.ValueMember = "Id";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.rutasDisponiblesBindingSource1, "Id", true));
            this.comboBox3.DataSource = this.rutasDisponiblesBindingSource;
            this.comboBox3.DisplayMember = "Id";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(184, 178);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 37;
            this.comboBox3.ValueMember = "Id";
            // 
            // sistemaAutobusesDataSet
            // 
            this.sistemaAutobusesDataSet.DataSetName = "SistemaAutobusesDataSet";
            this.sistemaAutobusesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // autobusesBindingSource
            // 
            this.autobusesBindingSource.DataMember = "Autobuses";
            this.autobusesBindingSource.DataSource = this.sistemaAutobusesDataSet;
            // 
            // autobusesTableAdapter
            // 
            this.autobusesTableAdapter.ClearBeforeFill = true;
            // 
            // autobusesBindingSource1
            // 
            this.autobusesBindingSource1.DataMember = "Autobuses";
            this.autobusesBindingSource1.DataSource = this.sistemaAutobusesDataSet;
            // 
            // sistemaAutobusesDataSet1
            // 
            this.sistemaAutobusesDataSet1.DataSetName = "SistemaAutobusesDataSet1";
            this.sistemaAutobusesDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // choferesBindingSource
            // 
            this.choferesBindingSource.DataMember = "Choferes";
            this.choferesBindingSource.DataSource = this.sistemaAutobusesDataSet1;
            // 
            // choferesTableAdapter
            // 
            this.choferesTableAdapter.ClearBeforeFill = true;
            // 
            // sistemaAutobusesDataSet2
            // 
            this.sistemaAutobusesDataSet2.DataSetName = "SistemaAutobusesDataSet2";
            this.sistemaAutobusesDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rutasBindingSource
            // 
            this.rutasBindingSource.DataMember = "Rutas";
            this.rutasBindingSource.DataSource = this.sistemaAutobusesDataSet2;
            // 
            // rutasTableAdapter
            // 
            this.rutasTableAdapter.ClearBeforeFill = true;
            // 
            // sistemaAutobusesDataSet6
            // 
            this.sistemaAutobusesDataSet6.DataSetName = "SistemaAutobusesDataSet6";
            this.sistemaAutobusesDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // choferesDisponiblesBindingSource
            // 
            this.choferesDisponiblesBindingSource.DataMember = "ChoferesDisponibles";
            this.choferesDisponiblesBindingSource.DataSource = this.sistemaAutobusesDataSet6;
            // 
            // choferesDisponiblesTableAdapter
            // 
            this.choferesDisponiblesTableAdapter.ClearBeforeFill = true;
            // 
            // autobusesDisponiblesBindingSource
            // 
            this.autobusesDisponiblesBindingSource.DataMember = "AutobusesDisponibles";
            this.autobusesDisponiblesBindingSource.DataSource = this.sistemaAutobusesDataSet6;
            // 
            // autobusesDisponiblesTableAdapter
            // 
            this.autobusesDisponiblesTableAdapter.ClearBeforeFill = true;
            // 
            // autobusesDisponiblesBindingSource1
            // 
            this.autobusesDisponiblesBindingSource1.DataMember = "AutobusesDisponibles";
            this.autobusesDisponiblesBindingSource1.DataSource = this.sistemaAutobusesDataSet6;
            // 
            // rutasDisponiblesBindingSource
            // 
            this.rutasDisponiblesBindingSource.DataMember = "RutasDisponibles";
            this.rutasDisponiblesBindingSource.DataSource = this.sistemaAutobusesDataSet6;
            // 
            // rutasDisponiblesTableAdapter
            // 
            this.rutasDisponiblesTableAdapter.ClearBeforeFill = true;
            // 
            // rutasDisponiblesBindingSource1
            // 
            this.rutasDisponiblesBindingSource1.DataMember = "RutasDisponibles";
            this.rutasDisponiblesBindingSource1.DataSource = this.sistemaAutobusesDataSet6;
            // 
            // sistemaAutobusesDataSet7
            // 
            this.sistemaAutobusesDataSet7.DataSetName = "SistemaAutobusesDataSet7";
            this.sistemaAutobusesDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // viajesDisponiblesBindingSource
            // 
            this.viajesDisponiblesBindingSource.DataMember = "ViajesDisponibles";
            this.viajesDisponiblesBindingSource.DataSource = this.sistemaAutobusesDataSet7;
            // 
            // viajesDisponiblesTableAdapter
            // 
            this.viajesDisponiblesTableAdapter.ClearBeforeFill = true;
            // 
            // sistemaAutobusesDataSet8
            // 
            this.sistemaAutobusesDataSet8.DataSetName = "SistemaAutobusesDataSet8";
            this.sistemaAutobusesDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // insertarViajeConDescripcionesBindingSource
            // 
            this.insertarViajeConDescripcionesBindingSource.DataMember = "InsertarViajeConDescripciones";
            this.insertarViajeConDescripcionesBindingSource.DataSource = this.sistemaAutobusesDataSet8;
            // 
            // insertarViajeConDescripcionesTableAdapter
            // 
            this.insertarViajeConDescripcionesTableAdapter.ClearBeforeFill = true;
            // 
            // sistemaAutobusesDataSet9
            // 
            this.sistemaAutobusesDataSet9.DataSetName = "SistemaAutobusesDataSet9";
            this.sistemaAutobusesDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // viajesConDescripciones3BindingSource
            // 
            this.viajesConDescripciones3BindingSource.DataMember = "ViajesConDescripciones3";
            this.viajesConDescripciones3BindingSource.DataSource = this.sistemaAutobusesDataSet9;
            // 
            // viajesConDescripciones3TableAdapter
            // 
            this.viajesConDescripciones3TableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.viajeIdDataGridViewTextBoxColumn,
            this.choferIdDataGridViewTextBoxColumn1,
            this.nombreChoferDataGridViewTextBoxColumn,
            this.apellidoChoferDataGridViewTextBoxColumn,
            this.autobusIdDataGridViewTextBoxColumn1,
            this.marcaAutobusDataGridViewTextBoxColumn,
            this.rutaIdDataGridViewTextBoxColumn1,
            this.nombreRutaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.viajesConDescripciones3BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-16, 306);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(827, 109);
            this.dataGridView1.TabIndex = 38;
            // 
            // viajeIdDataGridViewTextBoxColumn
            // 
            this.viajeIdDataGridViewTextBoxColumn.DataPropertyName = "ViajeId";
            this.viajeIdDataGridViewTextBoxColumn.HeaderText = "ViajeId";
            this.viajeIdDataGridViewTextBoxColumn.Name = "viajeIdDataGridViewTextBoxColumn";
            // 
            // choferIdDataGridViewTextBoxColumn1
            // 
            this.choferIdDataGridViewTextBoxColumn1.DataPropertyName = "ChoferId";
            this.choferIdDataGridViewTextBoxColumn1.HeaderText = "ChoferId";
            this.choferIdDataGridViewTextBoxColumn1.Name = "choferIdDataGridViewTextBoxColumn1";
            // 
            // nombreChoferDataGridViewTextBoxColumn
            // 
            this.nombreChoferDataGridViewTextBoxColumn.DataPropertyName = "NombreChofer";
            this.nombreChoferDataGridViewTextBoxColumn.HeaderText = "NombreChofer";
            this.nombreChoferDataGridViewTextBoxColumn.Name = "nombreChoferDataGridViewTextBoxColumn";
            // 
            // apellidoChoferDataGridViewTextBoxColumn
            // 
            this.apellidoChoferDataGridViewTextBoxColumn.DataPropertyName = "ApellidoChofer";
            this.apellidoChoferDataGridViewTextBoxColumn.HeaderText = "ApellidoChofer";
            this.apellidoChoferDataGridViewTextBoxColumn.Name = "apellidoChoferDataGridViewTextBoxColumn";
            // 
            // autobusIdDataGridViewTextBoxColumn1
            // 
            this.autobusIdDataGridViewTextBoxColumn1.DataPropertyName = "AutobusId";
            this.autobusIdDataGridViewTextBoxColumn1.HeaderText = "AutobusId";
            this.autobusIdDataGridViewTextBoxColumn1.Name = "autobusIdDataGridViewTextBoxColumn1";
            // 
            // marcaAutobusDataGridViewTextBoxColumn
            // 
            this.marcaAutobusDataGridViewTextBoxColumn.DataPropertyName = "MarcaAutobus";
            this.marcaAutobusDataGridViewTextBoxColumn.HeaderText = "MarcaAutobus";
            this.marcaAutobusDataGridViewTextBoxColumn.Name = "marcaAutobusDataGridViewTextBoxColumn";
            // 
            // rutaIdDataGridViewTextBoxColumn1
            // 
            this.rutaIdDataGridViewTextBoxColumn1.DataPropertyName = "RutaId";
            this.rutaIdDataGridViewTextBoxColumn1.HeaderText = "RutaId";
            this.rutaIdDataGridViewTextBoxColumn1.Name = "rutaIdDataGridViewTextBoxColumn1";
            // 
            // nombreRutaDataGridViewTextBoxColumn
            // 
            this.nombreRutaDataGridViewTextBoxColumn.DataPropertyName = "NombreRuta";
            this.nombreRutaDataGridViewTextBoxColumn.HeaderText = "NombreRuta";
            this.nombreRutaDataGridViewTextBoxColumn.Name = "nombreRutaDataGridViewTextBoxColumn";
            // 
            // rutaIdDataGridViewTextBoxColumn
            // 
            this.rutaIdDataGridViewTextBoxColumn.DataPropertyName = "RutaId";
            this.rutaIdDataGridViewTextBoxColumn.HeaderText = "RutaId";
            this.rutaIdDataGridViewTextBoxColumn.Name = "rutaIdDataGridViewTextBoxColumn";
            // 
            // autobusIdDataGridViewTextBoxColumn
            // 
            this.autobusIdDataGridViewTextBoxColumn.DataPropertyName = "AutobusId";
            this.autobusIdDataGridViewTextBoxColumn.HeaderText = "AutobusId";
            this.autobusIdDataGridViewTextBoxColumn.Name = "autobusIdDataGridViewTextBoxColumn";
            // 
            // choferIdDataGridViewTextBoxColumn
            // 
            this.choferIdDataGridViewTextBoxColumn.DataPropertyName = "ChoferId";
            this.choferIdDataGridViewTextBoxColumn.HeaderText = "ChoferId";
            this.choferIdDataGridViewTextBoxColumn.Name = "choferIdDataGridViewTextBoxColumn";
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.choferIdDataGridViewTextBoxColumn,
            this.autobusIdDataGridViewTextBoxColumn,
            this.rutaIdDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.viajesBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(340, 78);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(394, 135);
            this.dataGridView2.TabIndex = 20;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // interfaz_Viajes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.dataGridView2);
            this.Name = "interfaz_Viajes";
            this.Text = "interfaz_Viajes";
            this.Load += new System.EventHandler(this.interfaz_Viajes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._SistemaAutobuses_DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viajesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.choferesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rutasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.choferesDisponiblesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesDisponiblesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.autobusesDisponiblesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rutasDisponiblesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rutasDisponiblesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viajesDisponiblesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.insertarViajeConDescripcionesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemaAutobusesDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viajesConDescripciones3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.BindingSource sistemaAutobusesDataSet1BindingSource;
        private _SistemaAutobuses_DataSet1 _SistemaAutobuses_DataSet1;
        private SistemaAutobusesDataSet3 sistemaAutobusesDataSet3;
        private System.Windows.Forms.BindingSource viajesBindingSource;
        private SistemaAutobusesDataSet3TableAdapters.ViajesTableAdapter viajesTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private SistemaAutobusesDataSet sistemaAutobusesDataSet;
        private System.Windows.Forms.BindingSource autobusesBindingSource;
        private SistemaAutobusesDataSetTableAdapters.AutobusesTableAdapter autobusesTableAdapter;
        private System.Windows.Forms.BindingSource autobusesBindingSource1;
        private SistemaAutobusesDataSet1 sistemaAutobusesDataSet1;
        private System.Windows.Forms.BindingSource choferesBindingSource;
        private SistemaAutobusesDataSet1TableAdapters.ChoferesTableAdapter choferesTableAdapter;
        private SistemaAutobusesDataSet2 sistemaAutobusesDataSet2;
        private System.Windows.Forms.BindingSource rutasBindingSource;
        private SistemaAutobusesDataSet2TableAdapters.RutasTableAdapter rutasTableAdapter;
        private SistemaAutobusesDataSet6 sistemaAutobusesDataSet6;
        private System.Windows.Forms.BindingSource choferesDisponiblesBindingSource;
        private SistemaAutobusesDataSet6TableAdapters.ChoferesDisponiblesTableAdapter choferesDisponiblesTableAdapter;
        private System.Windows.Forms.BindingSource autobusesDisponiblesBindingSource;
        private SistemaAutobusesDataSet6TableAdapters.AutobusesDisponiblesTableAdapter autobusesDisponiblesTableAdapter;
        private System.Windows.Forms.BindingSource autobusesDisponiblesBindingSource1;
        private System.Windows.Forms.BindingSource rutasDisponiblesBindingSource;
        private SistemaAutobusesDataSet6TableAdapters.RutasDisponiblesTableAdapter rutasDisponiblesTableAdapter;
        private System.Windows.Forms.BindingSource rutasDisponiblesBindingSource1;
        private SistemaAutobusesDataSet7 sistemaAutobusesDataSet7;
        private System.Windows.Forms.BindingSource viajesDisponiblesBindingSource;
        private SistemaAutobusesDataSet7TableAdapters.ViajesDisponiblesTableAdapter viajesDisponiblesTableAdapter;
        private System.Windows.Forms.BindingSource insertarViajeConDescripcionesBindingSource;
        private SistemaAutobusesDataSet8 sistemaAutobusesDataSet8;
        private SistemaAutobusesDataSet8TableAdapters.InsertarViajeConDescripcionesTableAdapter insertarViajeConDescripcionesTableAdapter;
        private SistemaAutobusesDataSet9 sistemaAutobusesDataSet9;
        private System.Windows.Forms.BindingSource viajesConDescripciones3BindingSource;
        private SistemaAutobusesDataSet9TableAdapters.ViajesConDescripciones3TableAdapter viajesConDescripciones3TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn viajeIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn choferIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreChoferDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoChoferDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn autobusIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn marcaAutobusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rutaIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreRutaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rutaIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn autobusIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn choferIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}
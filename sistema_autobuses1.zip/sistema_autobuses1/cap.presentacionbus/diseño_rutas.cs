﻿using SistemaControlAutobuses.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace cap.presentacionbus
{
    public partial class diseño_rutas : Form
    {
        public diseño_rutas()
        {
            InitializeComponent();
        }

        private void diseño_rutas_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistemaAutobusesDataSet2.Rutas' Puede moverla o quitarla según sea necesario.
            this.rutasTableAdapter.Fill(this.sistemaAutobusesDataSet2.Rutas);

        }
        private void LimpiarCamposRutas()
        {
            // Limpiar los campos de texto
            textBox1.Clear(); // Nombre de la ruta
            textBox4.Clear(); // Distancia
            textBox3.Clear(); // Paradas
        }
        private void ActualizarDataGridViewRutas()
        {
            // Obtener los datos actualizados de la base de datos
            DataAccess dataAccess = new DataAccess();
            DataTable rutasDataTable = dataAccess.ListarRutas();

            // Asignar los datos al DataGridView de rutas
            dataGridView2.DataSource = rutasDataTable;
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
          
                // Obtener los valores ingresados en los TextBoxes
                string nombre = textBox1.Text;
                double distancia = Convert.ToDouble(textBox4.Text); // Ajusta según el tipo de dato de la distancia
                string paradas = textBox3.Text;

                // Llamar al método de la capa de datos para insertar la ruta
                DataAccess dataAccess = new DataAccess();
                dataAccess.InsertarRuta(nombre, distancia, paradas);

                // Actualizar el DataGridView después de guardar
                ActualizarDataGridViewRutas();

                // Limpiar los campos de texto después de guardar
                LimpiarCamposRutas();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Obtener el ID de la ruta seleccionada
                int idRuta = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Id"].Value); // Asegúrate de que el nombre de la columna sea correcto

                // Llamar al método de la capa de datos para eliminar la ruta
                DataAccess dataAccess = new DataAccess();
                dataAccess.EliminarRuta(idRuta);

                // Actualizar el DataGridView después de eliminar
                ActualizarDataGridViewRutas();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Obtener el ID de la ruta seleccionada
                int idRuta = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Id"].Value); // Asegúrate de que el nombre de la columna sea correcto

                // Obtener los nuevos valores ingresados en los TextBoxes
                string nuevoNombre = textBox1.Text;
                double nuevaDistancia = Convert.ToDouble(textBox4.Text); // Ajusta según el tipo de dato de la distancia
                string nuevasParadas = textBox3.Text;

                // Llamar al método de la capa de datos para editar la ruta
                DataAccess dataAccess = new DataAccess();
                dataAccess.EditarRuta(idRuta, nuevoNombre, nuevaDistancia, nuevasParadas);

                // Actualizar el DataGridView después de editar
                ActualizarDataGridViewRutas();

                // Limpiar los campos de texto después de editar
                LimpiarCamposRutas();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una fila para editar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }
    }
}

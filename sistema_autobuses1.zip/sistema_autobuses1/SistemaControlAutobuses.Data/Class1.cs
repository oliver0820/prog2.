﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaControlAutobuses.Data
{
    public class DataAccess
    {
        private string connectionString = "Data Source=DESKTOP-JN6QEPA;Initial Catalog=SistemaAutobuses;Integrated Security=True";

        // Método para insertar un nuevo chofer en la base de datos
        public void InsertarChofer(string nombre, string apellido, DateTime fechaNacimiento, string cedula)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Choferes (Nombre, Apellido, FechaNacimiento, Cedula) VALUES (@Nombre, @Apellido, @FechaNacimiento, @Cedula,)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Apellido", apellido);
                command.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);
                command.Parameters.AddWithValue("@Cedula", cedula);

                connection.Open();
                command.ExecuteNonQuery();
            }


        }
    


        // Método para editar los datos de un chofer existente en la base de datos
        public void EditarChofer(int id, string nombre, string apellido, DateTime fechaNacimiento, string cedula)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Choferes SET Nombre = @Nombre, Apellido = @Apellido, FechaNacimiento = @FechaNacimiento, Cedula = @Cedula WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Apellido", apellido);
                command.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);
                command.Parameters.AddWithValue("@Cedula", cedula);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        // Método para eliminar un chofer por su ID
        public void EliminarChofer(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Choferes WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        // Método para obtener todos los choferes de la base de datos
        public DataTable ListarChoferes()
        {
            DataTable choferesDataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Choferes";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                choferesDataTable.Load(reader);
            }
            return choferesDataTable;
        }

        // Métodos para la entidad Autobus
        public void InsertarAutobus(string marca, string modelo, string placa, string color, int Año)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Autobuses (Marca, Modelo, Placa, Color,Año) VALUES (@Marca, @Modelo, @Placa, @Color, @Año)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Marca", marca);
                command.Parameters.AddWithValue("@Modelo", modelo);
                command.Parameters.AddWithValue("@Placa", placa);
                command.Parameters.AddWithValue("@Color", color);
                command.Parameters.AddWithValue("@Año", Año);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void EditarAutobus(int id, string marca, string modelo, string placa, string color, int Año)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Autobuses SET Marca = @Marca, Modelo = @Modelo, Placa = @Placa, Color = @Color, Año = @Año WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@Marca", marca);
                command.Parameters.AddWithValue("@Modelo", modelo);
                command.Parameters.AddWithValue("@Placa", placa);
                command.Parameters.AddWithValue("@Color", color);
                command.Parameters.AddWithValue("@Año", Año);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void EliminarAutobus(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Autobuses WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public DataTable ListarAutobuses()
        {
            DataTable autobusesDataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Autobuses";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                autobusesDataTable.Load(reader);
            }
            return autobusesDataTable;
        }

        public void InsertarRuta(string nombre, double distancia, string paradas)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Rutas (Nombre,Distancia_km, Paradas) VALUES (@Nombre, @Distancia_Km, @Paradas)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Distancia_km", distancia);
                command.Parameters.AddWithValue("@Paradas", paradas);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void EditarRuta(int id, string nombre, double distancia, string paradas)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Rutas SET Nombre = @Nombre, Distancia_km = @Distancia_Km, Paradas = @Paradas WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@Nombre", nombre);
                command.Parameters.AddWithValue("@Distancia_km", distancia);
                command.Parameters.AddWithValue("@Paradas", paradas);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void EliminarRuta(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Rutas WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public DataTable ListarRutas()
        {
            DataTable rutasDataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Rutas";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                rutasDataTable.Load(reader);
            }
            return rutasDataTable;
        }


        public void InsertarViaje(int choferId, int autobusId, int rutaId)
        {
            // Construir la consulta SQL de inserción
            string queryString = "INSERT INTO Viajes (ChoferId, AutobusId, RutaId) VALUES (@ChoferId, @AutobusId, @RutaId)";

            // Crear una conexión a la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abrir la conexión
                connection.Open();

                // Crear un comando SQL con la consulta y la conexión
                using (SqlCommand command = new SqlCommand(queryString, connection))
                {
                    // Asignar los valores de los parámetros
                    command.Parameters.AddWithValue("@ChoferId", choferId);
                    command.Parameters.AddWithValue("@AutobusId", autobusId);
                    command.Parameters.AddWithValue("@RutaId", rutaId);

                    // Ejecutar la consulta
                    command.ExecuteNonQuery();
                }
            }


        }
        public DataTable ListarViajes()
        {
            DataTable dataTable = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string queryString = "SELECT * FROM Viajes";
                    using (SqlCommand command = new SqlCommand(queryString, connection))
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                        dataAdapter.Fill(dataTable);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al listar los viajes: " + ex.Message);
            }

            return dataTable;
        }

        public void EliminarViaje(int viajeId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string queryString = "DELETE FROM Viajes WHERE Id = @ViajeId";
                    using (SqlCommand command = new SqlCommand(queryString, connection))
                    {
                        command.Parameters.AddWithValue("@ViajeId", viajeId);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al eliminar el viaje: " + ex.Message);
            }
        }

        public void EditarViaje(int viajeId, int choferId, int autobusId, int rutaId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string queryString = "UPDATE Viajes SET ChoferId = @ChoferId, AutobusId = @AutobusId, RutaId = @RutaId WHERE Id = @ViajeId";
                    using (SqlCommand command = new SqlCommand(queryString, connection))
                    {
                        command.Parameters.AddWithValue("@ChoferId", choferId);
                        command.Parameters.AddWithValue("@AutobusId", autobusId);
                        command.Parameters.AddWithValue("@RutaId", rutaId);
                        command.Parameters.AddWithValue("@ViajeId", viajeId);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al editar el viaje: " + ex.Message);
            }



            



        }
        public DataTable ObtenerViajesConDescripciones3()
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM ViajesConDescripciones3"; 
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(dataTable);
                }
            }
            return dataTable;
        }

        public void EditarViaje(int choferId, int autobusId, int rutaId)
        {
            throw new NotImplementedException();
        }
    }
}




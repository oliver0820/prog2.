﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos;
using negocio;

namespace presentacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'agenda_ElectronicaDataSet.Personas' Puede moverla o quitarla según sea necesario.
            this.personasTableAdapter.Fill(this.agenda_ElectronicaDataSet.Personas);

        }

      

        private void btn_Guardar_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Obtener los datos del formulario
                string nombre = tb_Nombre.Text;
                string apellido = tb_Apellido.Text;
                string fechaNacimiento = tb_Fecha.Value.ToString("yyyy-MM-dd"); // Obtener la fecha como string en formato 'yyyy-MM-dd'
                string direccion = tb_Direccion.Text;
                string genero =  tb_Genero.Text;
                string estadoCivil =tb_Estado.Text;
                string movil = tb_Movil.Text;
                string telefono = tb_Telefono.Text;
                string correoElectronico = tb_Correo.Text;

                // Llamar al método en la capa de lógica de negocio para guardar la persona
                bool exito = GestorPersonas.GuardarPersona(nombre, apellido, fechaNacimiento, direccion, genero, estadoCivil, movil, telefono, correoElectronico);

                if (exito)
                {
                    MessageBox.Show("Registro guardado correctamente");

                    // Actualizar la tabla
                    ActualizarTabla();
                }
                else
                {
                    MessageBox.Show("Error al guardar el registro");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void ActualizarTabla()
        {
            // Llamar al método en la capa de lógica de negocio para listar las personas
            DataTable datos = GestorPersonas.ObtenerListaPersonas();

            // Asignar los datos al origen de datos del DataGridView
            dg_Personas.DataSource = datos;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_Eliminar_Click(object sender, EventArgs e)
        {


            // Verificar si hay al menos una fila seleccionada en el DataGridView
            if (dg_Personas.SelectedRows.Count > 0)
            {
                // Obtener el ID de la persona seleccionada
                string idPersona = dg_Personas.SelectedRows[0].Cells["Id"].Value.ToString();

                // Llamar a la función de la capa de negocios para eliminar la persona
                try
                {
                    bool eliminado = negocio.GestorPersonas.EliminarPersona(idPersona);
                    if (eliminado)
                    {
                        MessageBox.Show("La persona ha sido eliminada correctamente.");
                        // Actualizar el DataGridView después de la eliminación si es necesario
                        // Actualizar la tabla
                        ActualizarTabla();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar la persona.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar la persona: " + ex.Message);
                }
            }
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            if (dg_Personas.Rows.Count > 1)
            {
                string Nombre = dg_Personas.CurrentRow.Cells["Nombre"].Value.ToString();
                string Apellido = dg_Personas.CurrentRow.Cells["apellidoDataGridViewTextBoxColumn"].Value.ToString();
                string Fecha = dg_Personas.CurrentRow.Cells["Fecha_Nacimiento"].Value.ToString();
                string Direccion = dg_Personas.CurrentRow.Cells["direccionDataGridViewTextBoxColumn"].Value.ToString();
                string Genero = dg_Personas.CurrentRow.Cells["Genero"].Value.ToString();
                string Estado = dg_Personas.CurrentRow.Cells["Estado_Civil"].Value.ToString();
                string Movil = dg_Personas.CurrentRow.Cells["Movil"].Value.ToString();
                string Telefono = dg_Personas.CurrentRow.Cells["Telefono"].Value.ToString();
                string Correo = dg_Personas.CurrentRow.Cells["Correo_Electronico"].Value.ToString();

                tb_Nombre.Text = Nombre;
                tb_Apellido.Text = Apellido;
                tb_Fecha.Text = Fecha;
                tb_Direccion.Text = Direccion;
                tb_Genero.Text = Genero;
                tb_Estado.Text = Estado;
                tb_Movil.Text = Movil;
                tb_Telefono.Text = Telefono;
                tb_Correo.Text = Correo;

                string ID = dg_Personas.CurrentRow.Cells["ID"].Value.ToString();
                ActualizarTabla();

            }
            else
            {
                MessageBox.Show("No hay registros para editar");
            }

            dg_Personas.DataSource = Personas.LeerDatos();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            string nombre = texb_Buscar.Text; // Obtener el texto ingresado en el control BunifuTextbox

            try
            {
                DataTable resultadoBusqueda = negocio.GestorPersonas.BuscarPersona(nombre);

                // Mostrar el resultado de la búsqueda en el DataGridView
                dg_Personas.DataSource = resultadoBusqueda;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al realizar la búsqueda: " + ex.Message);
            }
        }

        private void texb_Buscar_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void tb_Telefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void Género_Click(object sender, EventArgs e)
        {

        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

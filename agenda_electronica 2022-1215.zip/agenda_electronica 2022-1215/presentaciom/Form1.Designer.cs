﻿namespace presentacion
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dg_Personas = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fecha_Nacimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direccionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Genero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado_Civil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Movil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correo_Electronico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.personasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.agenda_ElectronicaDataSet = new presentaciom.Agenda_ElectronicaDataSet();
            this.tb_Correo = new System.Windows.Forms.TextBox();
            this.tb_Telefono = new System.Windows.Forms.TextBox();
            this.tb_Movil = new System.Windows.Forms.TextBox();
            this.tb_Apellido = new System.Windows.Forms.TextBox();
            this.tb_Nombre = new System.Windows.Forms.TextBox();
            this.Correo = new System.Windows.Forms.Label();
            this.Teléfono = new System.Windows.Forms.Label();
            this.Móvil = new System.Windows.Forms.Label();
            this.EstadoCivil = new System.Windows.Forms.Label();
            this.Género = new System.Windows.Forms.Label();
            this.Direccion = new System.Windows.Forms.Label();
            this.FechaNacimiento = new System.Windows.Forms.Label();
            this.Apellido = new System.Windows.Forms.Label();
            this.personasTableAdapter = new presentaciom.Agenda_ElectronicaDataSetTableAdapters.PersonasTableAdapter();
            this.tb_Fecha = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Guardar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.tb_Estado = new System.Windows.Forms.ComboBox();
            this.tb_Direccion = new System.Windows.Forms.TextBox();
            this.tb_Genero = new System.Windows.Forms.ComboBox();
            this.btn_Eliminar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Modificar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_buscar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label2 = new System.Windows.Forms.Label();
            this.texb_Buscar = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Personas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agenda_ElectronicaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_Personas
            // 
            this.dg_Personas.AutoGenerateColumns = false;
            this.dg_Personas.BackgroundColor = System.Drawing.Color.LightSeaGreen;
            this.dg_Personas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Personas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Nombre,
            this.apellidoDataGridViewTextBoxColumn,
            this.Fecha_Nacimiento,
            this.direccionDataGridViewTextBoxColumn,
            this.Genero,
            this.Estado_Civil,
            this.Movil,
            this.Telefono,
            this.Correo_Electronico});
            this.dg_Personas.DataSource = this.personasBindingSource;
            this.dg_Personas.Location = new System.Drawing.Point(32, 156);
            this.dg_Personas.Name = "dg_Personas";
            this.dg_Personas.Size = new System.Drawing.Size(498, 236);
            this.dg_Personas.TabIndex = 59;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // Nombre
            // 
            this.Nombre.DataPropertyName = "Nombre";
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            // 
            // apellidoDataGridViewTextBoxColumn
            // 
            this.apellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.Name = "apellidoDataGridViewTextBoxColumn";
            // 
            // Fecha_Nacimiento
            // 
            this.Fecha_Nacimiento.DataPropertyName = "Fecha_Nacimiento";
            this.Fecha_Nacimiento.HeaderText = "Fecha_Nacimiento";
            this.Fecha_Nacimiento.Name = "Fecha_Nacimiento";
            // 
            // direccionDataGridViewTextBoxColumn
            // 
            this.direccionDataGridViewTextBoxColumn.DataPropertyName = "Direccion";
            this.direccionDataGridViewTextBoxColumn.HeaderText = "Direccion";
            this.direccionDataGridViewTextBoxColumn.Name = "direccionDataGridViewTextBoxColumn";
            // 
            // Genero
            // 
            this.Genero.DataPropertyName = "Genero";
            this.Genero.HeaderText = "Genero";
            this.Genero.Name = "Genero";
            // 
            // Estado_Civil
            // 
            this.Estado_Civil.DataPropertyName = "Estado_Civil";
            this.Estado_Civil.HeaderText = "Estado_Civil";
            this.Estado_Civil.Name = "Estado_Civil";
            // 
            // Movil
            // 
            this.Movil.DataPropertyName = "Movil";
            this.Movil.HeaderText = "Movil";
            this.Movil.Name = "Movil";
            // 
            // Telefono
            // 
            this.Telefono.DataPropertyName = "Telefono";
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            // 
            // Correo_Electronico
            // 
            this.Correo_Electronico.DataPropertyName = "Correo_Electronico";
            this.Correo_Electronico.HeaderText = "Correo_Electronico";
            this.Correo_Electronico.Name = "Correo_Electronico";
            // 
            // personasBindingSource
            // 
            this.personasBindingSource.DataMember = "Personas";
            this.personasBindingSource.DataSource = this.agenda_ElectronicaDataSet;
            // 
            // agenda_ElectronicaDataSet
            // 
            this.agenda_ElectronicaDataSet.DataSetName = "Agenda_ElectronicaDataSet";
            this.agenda_ElectronicaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_Correo
            // 
            this.tb_Correo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Correo.Location = new System.Drawing.Point(727, 414);
            this.tb_Correo.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Correo.Name = "tb_Correo";
            this.tb_Correo.Size = new System.Drawing.Size(179, 29);
            this.tb_Correo.TabIndex = 54;
            // 
            // tb_Telefono
            // 
            this.tb_Telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Telefono.Location = new System.Drawing.Point(727, 372);
            this.tb_Telefono.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Telefono.Name = "tb_Telefono";
            this.tb_Telefono.Size = new System.Drawing.Size(179, 29);
            this.tb_Telefono.TabIndex = 53;
            this.tb_Telefono.TextChanged += new System.EventHandler(this.tb_Telefono_TextChanged);
            // 
            // tb_Movil
            // 
            this.tb_Movil.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Movil.Location = new System.Drawing.Point(727, 335);
            this.tb_Movil.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Movil.Name = "tb_Movil";
            this.tb_Movil.Size = new System.Drawing.Size(179, 29);
            this.tb_Movil.TabIndex = 52;
            // 
            // tb_Apellido
            // 
            this.tb_Apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Apellido.Location = new System.Drawing.Point(736, 156);
            this.tb_Apellido.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Apellido.Name = "tb_Apellido";
            this.tb_Apellido.Size = new System.Drawing.Size(179, 29);
            this.tb_Apellido.TabIndex = 48;
            // 
            // tb_Nombre
            // 
            this.tb_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Nombre.Location = new System.Drawing.Point(736, 110);
            this.tb_Nombre.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Nombre.Name = "tb_Nombre";
            this.tb_Nombre.Size = new System.Drawing.Size(179, 29);
            this.tb_Nombre.TabIndex = 47;
            // 
            // Correo
            // 
            this.Correo.AutoSize = true;
            this.Correo.BackColor = System.Drawing.Color.Transparent;
            this.Correo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Correo.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Correo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Correo.Location = new System.Drawing.Point(585, 409);
            this.Correo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Correo.Name = "Correo";
            this.Correo.Size = new System.Drawing.Size(106, 32);
            this.Correo.TabIndex = 45;
            this.Correo.Text = "EMAIL:";
            // 
            // Teléfono
            // 
            this.Teléfono.AutoSize = true;
            this.Teléfono.BackColor = System.Drawing.Color.Transparent;
            this.Teléfono.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Teléfono.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Teléfono.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Teléfono.Location = new System.Drawing.Point(573, 373);
            this.Teléfono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Teléfono.Name = "Teléfono";
            this.Teléfono.Size = new System.Drawing.Size(136, 32);
            this.Teléfono.TabIndex = 44;
            this.Teléfono.Text = "Teléfono:";
            // 
            // Móvil
            // 
            this.Móvil.AutoSize = true;
            this.Móvil.BackColor = System.Drawing.Color.Transparent;
            this.Móvil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Móvil.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Móvil.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Móvil.Location = new System.Drawing.Point(592, 336);
            this.Móvil.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Móvil.Name = "Móvil";
            this.Móvil.Size = new System.Drawing.Size(92, 32);
            this.Móvil.TabIndex = 43;
            this.Móvil.Text = "Móvil:";
            // 
            // EstadoCivil
            // 
            this.EstadoCivil.AutoEllipsis = true;
            this.EstadoCivil.AutoSize = true;
            this.EstadoCivil.BackColor = System.Drawing.Color.Transparent;
            this.EstadoCivil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.EstadoCivil.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EstadoCivil.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EstadoCivil.Location = new System.Drawing.Point(549, 295);
            this.EstadoCivil.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.EstadoCivil.Name = "EstadoCivil";
            this.EstadoCivil.Size = new System.Drawing.Size(173, 32);
            this.EstadoCivil.TabIndex = 42;
            this.EstadoCivil.Text = "Estado Civil:";
            // 
            // Género
            // 
            this.Género.AutoSize = true;
            this.Género.BackColor = System.Drawing.Color.Transparent;
            this.Género.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Género.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Género.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Género.Location = new System.Drawing.Point(585, 264);
            this.Género.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Género.Name = "Género";
            this.Género.Size = new System.Drawing.Size(118, 32);
            this.Género.TabIndex = 41;
            this.Género.Text = "Género:";
            this.Género.Click += new System.EventHandler(this.Género_Click);
            // 
            // Direccion
            // 
            this.Direccion.AutoSize = true;
            this.Direccion.BackColor = System.Drawing.Color.Transparent;
            this.Direccion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Direccion.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Direccion.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Direccion.Location = new System.Drawing.Point(575, 236);
            this.Direccion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Direccion.Name = "Direccion";
            this.Direccion.Size = new System.Drawing.Size(148, 32);
            this.Direccion.TabIndex = 40;
            this.Direccion.Text = "Dirección:";
            // 
            // FechaNacimiento
            // 
            this.FechaNacimiento.AutoSize = true;
            this.FechaNacimiento.BackColor = System.Drawing.Color.Transparent;
            this.FechaNacimiento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FechaNacimiento.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FechaNacimiento.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FechaNacimiento.Location = new System.Drawing.Point(573, 200);
            this.FechaNacimiento.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FechaNacimiento.Name = "FechaNacimiento";
            this.FechaNacimiento.Size = new System.Drawing.Size(161, 32);
            this.FechaNacimiento.TabIndex = 39;
            this.FechaNacimiento.Text = "Fecha Nac: ";
            // 
            // Apellido
            // 
            this.Apellido.AutoSize = true;
            this.Apellido.BackColor = System.Drawing.Color.Transparent;
            this.Apellido.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Apellido.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apellido.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Apellido.Location = new System.Drawing.Point(585, 153);
            this.Apellido.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Apellido.Name = "Apellido";
            this.Apellido.Size = new System.Drawing.Size(133, 32);
            this.Apellido.TabIndex = 38;
            this.Apellido.Text = "Apellido:";
            // 
            // personasTableAdapter
            // 
            this.personasTableAdapter.ClearBeforeFill = true;
            // 
            // tb_Fecha
            // 
            this.tb_Fecha.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tb_Fecha.BorderRadius = 0;
            this.tb_Fecha.ForeColor = System.Drawing.Color.Black;
            this.tb_Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.tb_Fecha.FormatCustom = null;
            this.tb_Fecha.Location = new System.Drawing.Point(738, 200);
            this.tb_Fecha.Name = "tb_Fecha";
            this.tb_Fecha.Size = new System.Drawing.Size(179, 34);
            this.tb_Fecha.TabIndex = 62;
            this.tb_Fecha.Value = new System.DateTime(2024, 4, 2, 11, 40, 33, 209);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "bunifuFlatButton1";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(-23, -46);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(241, 48);
            this.bunifuFlatButton1.TabIndex = 64;
            this.bunifuFlatButton1.Text = "bunifuFlatButton1";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Guardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Guardar.BorderRadius = 0;
            this.btn_Guardar.ButtonText = "Guardar";
            this.btn_Guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Guardar.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Guardar.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Guardar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btn_Guardar.Iconimage")));
            this.btn_Guardar.Iconimage_right = null;
            this.btn_Guardar.Iconimage_right_Selected = null;
            this.btn_Guardar.Iconimage_Selected = null;
            this.btn_Guardar.IconMarginLeft = 0;
            this.btn_Guardar.IconMarginRight = 0;
            this.btn_Guardar.IconRightVisible = true;
            this.btn_Guardar.IconRightZoom = 0D;
            this.btn_Guardar.IconVisible = true;
            this.btn_Guardar.IconZoom = 90D;
            this.btn_Guardar.IsTab = false;
            this.btn_Guardar.Location = new System.Drawing.Point(66, 401);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Guardar.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btn_Guardar.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Guardar.selected = false;
            this.btn_Guardar.Size = new System.Drawing.Size(128, 42);
            this.btn_Guardar.TabIndex = 65;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Guardar.Textcolor = System.Drawing.Color.White;
            this.btn_Guardar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click_1);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "bunifuFlatButton3";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(-23, -46);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(241, 48);
            this.bunifuFlatButton3.TabIndex = 67;
            this.bunifuFlatButton3.Text = "bunifuFlatButton3";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // tb_Estado
            // 
            this.tb_Estado.FormattingEnabled = true;
            this.tb_Estado.Items.AddRange(new object[] {
            "Casad@",
            "Solter@",
            "Divorciad@"});
            this.tb_Estado.Location = new System.Drawing.Point(736, 302);
            this.tb_Estado.Name = "tb_Estado";
            this.tb_Estado.Size = new System.Drawing.Size(179, 21);
            this.tb_Estado.TabIndex = 70;
            this.tb_Estado.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // tb_Direccion
            // 
            this.tb_Direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Direccion.Location = new System.Drawing.Point(738, 239);
            this.tb_Direccion.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Direccion.Name = "tb_Direccion";
            this.tb_Direccion.Size = new System.Drawing.Size(179, 29);
            this.tb_Direccion.TabIndex = 49;
            // 
            // tb_Genero
            // 
            this.tb_Genero.FormattingEnabled = true;
            this.tb_Genero.Items.AddRange(new object[] {
            "Masculino",
            "Femenino"});
            this.tb_Genero.Location = new System.Drawing.Point(738, 273);
            this.tb_Genero.Name = "tb_Genero";
            this.tb_Genero.Size = new System.Drawing.Size(179, 21);
            this.tb_Genero.TabIndex = 71;
            // 
            // btn_Eliminar
            // 
            this.btn_Eliminar.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Eliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Eliminar.BorderRadius = 1;
            this.btn_Eliminar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btn_Eliminar.ButtonText = "Eliminar";
            this.btn_Eliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Eliminar.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Eliminar.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Eliminar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btn_Eliminar.Iconimage")));
            this.btn_Eliminar.Iconimage_right = null;
            this.btn_Eliminar.Iconimage_right_Selected = null;
            this.btn_Eliminar.Iconimage_Selected = null;
            this.btn_Eliminar.IconMarginLeft = 0;
            this.btn_Eliminar.IconMarginRight = 0;
            this.btn_Eliminar.IconRightVisible = true;
            this.btn_Eliminar.IconRightZoom = 0D;
            this.btn_Eliminar.IconVisible = true;
            this.btn_Eliminar.IconZoom = 90D;
            this.btn_Eliminar.IsTab = false;
            this.btn_Eliminar.Location = new System.Drawing.Point(373, 401);
            this.btn_Eliminar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Eliminar.Name = "btn_Eliminar";
            this.btn_Eliminar.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Eliminar.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btn_Eliminar.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Eliminar.selected = false;
            this.btn_Eliminar.Size = new System.Drawing.Size(126, 42);
            this.btn_Eliminar.TabIndex = 72;
            this.btn_Eliminar.Text = "Eliminar";
            this.btn_Eliminar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Eliminar.Textcolor = System.Drawing.Color.White;
            this.btn_Eliminar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Eliminar.Click += new System.EventHandler(this.btn_Eliminar_Click);
            // 
            // btn_Modificar
            // 
            this.btn_Modificar.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Modificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Modificar.BorderRadius = 0;
            this.btn_Modificar.ButtonText = "Modificar";
            this.btn_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Modificar.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Modificar.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Modificar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btn_Modificar.Iconimage")));
            this.btn_Modificar.Iconimage_right = null;
            this.btn_Modificar.Iconimage_right_Selected = null;
            this.btn_Modificar.Iconimage_Selected = null;
            this.btn_Modificar.IconMarginLeft = 0;
            this.btn_Modificar.IconMarginRight = 0;
            this.btn_Modificar.IconRightVisible = true;
            this.btn_Modificar.IconRightZoom = 0D;
            this.btn_Modificar.IconVisible = true;
            this.btn_Modificar.IconZoom = 90D;
            this.btn_Modificar.IsTab = false;
            this.btn_Modificar.Location = new System.Drawing.Point(225, 401);
            this.btn_Modificar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Modificar.Name = "btn_Modificar";
            this.btn_Modificar.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_Modificar.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btn_Modificar.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Modificar.selected = false;
            this.btn_Modificar.Size = new System.Drawing.Size(114, 42);
            this.btn_Modificar.TabIndex = 73;
            this.btn_Modificar.Text = "Modificar";
            this.btn_Modificar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Modificar.Textcolor = System.Drawing.Color.White;
            this.btn_Modificar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Modificar.Click += new System.EventHandler(this.btn_Modificar_Click);
            // 
            // btn_buscar
            // 
            this.btn_buscar.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_buscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.BorderRadius = 0;
            this.btn_buscar.ButtonText = "Buscar";
            this.btn_buscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_buscar.DisabledColor = System.Drawing.Color.Gray;
            this.btn_buscar.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_buscar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.Iconimage")));
            this.btn_buscar.Iconimage_right = null;
            this.btn_buscar.Iconimage_right_Selected = null;
            this.btn_buscar.Iconimage_Selected = null;
            this.btn_buscar.IconMarginLeft = 0;
            this.btn_buscar.IconMarginRight = 0;
            this.btn_buscar.IconRightVisible = true;
            this.btn_buscar.IconRightZoom = 0D;
            this.btn_buscar.IconVisible = true;
            this.btn_buscar.IconZoom = 90D;
            this.btn_buscar.IsTab = false;
            this.btn_buscar.Location = new System.Drawing.Point(351, 124);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btn_buscar.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btn_buscar.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_buscar.selected = false;
            this.btn_buscar.Size = new System.Drawing.Size(121, 36);
            this.btn_buscar.TabIndex = 74;
            this.btn_buscar.Text = "Buscar";
            this.btn_buscar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_buscar.Textcolor = System.Drawing.Color.White;
            this.btn_buscar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(585, 107);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 32);
            this.label2.TabIndex = 78;
            this.label2.Text = "Nombre:";
            // 
            // texb_Buscar
            // 
            this.texb_Buscar.BackColor = System.Drawing.Color.Silver;
            this.texb_Buscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.texb_Buscar.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.texb_Buscar.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.texb_Buscar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.texb_Buscar.HintForeColor = System.Drawing.Color.Empty;
            this.texb_Buscar.HintText = "";
            this.texb_Buscar.isPassword = false;
            this.texb_Buscar.LineFocusedColor = System.Drawing.Color.Blue;
            this.texb_Buscar.LineIdleColor = System.Drawing.Color.GhostWhite;
            this.texb_Buscar.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.texb_Buscar.LineThickness = 3;
            this.texb_Buscar.Location = new System.Drawing.Point(135, 124);
            this.texb_Buscar.Margin = new System.Windows.Forms.Padding(4);
            this.texb_Buscar.Name = "texb_Buscar";
            this.texb_Buscar.Size = new System.Drawing.Size(221, 38);
            this.texb_Buscar.TabIndex = 77;
            this.texb_Buscar.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.texb_Buscar.OnValueChanged += new System.EventHandler(this.texb_Buscar_OnValueChanged);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.InitialImage")));
            this.bunifuImageButton1.Location = new System.Drawing.Point(12, -16);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(917, 108);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 81;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(-23, -46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 82;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(917, 450);
            this.Controls.Add(this.FechaNacimiento);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Modificar);
            this.Controls.Add(this.btn_Eliminar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.tb_Genero);
            this.Controls.Add(this.tb_Estado);
            this.Controls.Add(this.bunifuFlatButton3);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.tb_Fecha);
            this.Controls.Add(this.dg_Personas);
            this.Controls.Add(this.tb_Correo);
            this.Controls.Add(this.tb_Telefono);
            this.Controls.Add(this.tb_Movil);
            this.Controls.Add(this.tb_Direccion);
            this.Controls.Add(this.tb_Apellido);
            this.Controls.Add(this.tb_Nombre);
            this.Controls.Add(this.Correo);
            this.Controls.Add(this.Teléfono);
            this.Controls.Add(this.Móvil);
            this.Controls.Add(this.EstadoCivil);
            this.Controls.Add(this.Género);
            this.Controls.Add(this.Direccion);
            this.Controls.Add(this.Apellido);
            this.Controls.Add(this.bunifuImageButton1);
            this.Controls.Add(this.texb_Buscar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_Personas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agenda_ElectronicaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dg_Personas;
        private System.Windows.Forms.TextBox tb_Correo;
        private System.Windows.Forms.TextBox tb_Telefono;
        private System.Windows.Forms.TextBox tb_Movil;
        private System.Windows.Forms.TextBox tb_Apellido;
        private System.Windows.Forms.TextBox tb_Nombre;
        private System.Windows.Forms.Label Correo;
        private System.Windows.Forms.Label Teléfono;
        private System.Windows.Forms.Label Móvil;
        private System.Windows.Forms.Label EstadoCivil;
        private System.Windows.Forms.Label Género;
        private System.Windows.Forms.Label Direccion;
        private System.Windows.Forms.Label FechaNacimiento;
        private System.Windows.Forms.Label Apellido;
        private presentaciom.Agenda_ElectronicaDataSet agenda_ElectronicaDataSet;
        private System.Windows.Forms.BindingSource personasBindingSource;
        private presentaciom.Agenda_ElectronicaDataSetTableAdapters.PersonasTableAdapter personasTableAdapter;
        private Bunifu.Framework.UI.BunifuDatepicker tb_Fecha;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Guardar;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private System.Windows.Forms.ComboBox tb_Estado;
        private System.Windows.Forms.TextBox tb_Direccion;
        private System.Windows.Forms.ComboBox tb_Genero;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Eliminar;
        private Bunifu.Framework.UI.BunifuFlatButton btn_Modificar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha_Nacimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn direccionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Genero;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado_Civil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Movil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correo_Electronico;
        private Bunifu.Framework.UI.BunifuFlatButton btn_buscar;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox texb_Buscar;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Personas
    {
        static string ConnectionString = "Data Source=DESKTOP-JN6QEPA;Initial Catalog=Agenda_Electronica;Integrated Security=True";


        public static DataTable LeerDatos()
        {
            DataTable dt_ListaPersonas = new DataTable();
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand comm = new SqlCommand("Select * from Personas", conn);

            try
            {

                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(comm);
                da.Fill(dt_ListaPersonas);
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }

            return dt_ListaPersonas;
        }

        public static bool Guardar_Registro(String Nombre, String Apellido, String Fecha_Nacimiento, String Direccion, String Genero, String Estado_Civil, String Movil, String Telefono, String Correo_Electronico)
        {
            bool Exito = false;

            SqlConnection conn = new SqlConnection(ConnectionString);
            string query = "INSERT INTO Personas (Nombre, Apellido, Fecha_Nacimiento, Direccion, Genero, Estado_Civil, Movil, Telefono, Correo_Electronico) " +
                "Values(@Nombre, @Apellido, @Fecha_Nacimiento, @Direccion, @Genero, @Estado_Civil, @Movil, @Telefono, @Correo_Electronico)";

            SqlCommand comm = new SqlCommand(query, conn);

            comm.Parameters.AddWithValue("@Nombre", Nombre);
            comm.Parameters.AddWithValue("@Apellido", Apellido);
            comm.Parameters.AddWithValue("@Fecha_Nacimiento", Fecha_Nacimiento); // La fecha se pasa como cadena
            comm.Parameters.AddWithValue("@Direccion", Direccion);
            comm.Parameters.AddWithValue("@Genero", Genero);
            comm.Parameters.AddWithValue("@Estado_Civil", Estado_Civil);
            comm.Parameters.AddWithValue("@Movil", Movil);
            comm.Parameters.AddWithValue("@Telefono", Telefono);
            comm.Parameters.AddWithValue("@Correo_Electronico", Correo_Electronico);

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                Exito = true;
            }
            catch (Exception)
            {
                // Manejo de errores
            }
            finally
            {
                conn.Close();
            }

            return Exito;
        }

        public static bool Actualizar_Registro(String Nombre, String Apellido, String Fecha_Nacimiento, String Direccion, String Genero, String Estado_Civil, String Movil, String Telefono, String Correo_Electronico, String ID)
        {
            bool Exito = false;

            SqlConnection conn = new SqlConnection(ConnectionString);
            string query = "UPDATE Personas SET Nombre = @Nombre, Apellido = @Apellido, Fecha_Nacimiento = @Fecha_Nacimiento, Direccion = @Direccion, Genero = @Genero,Estado_Civil = @Estado_Civil, Movil = @Movil, Telefono = @Telefono, Correo_Electronico = @Correo_Electronico where ID = @ID;";


            SqlCommand comm = new SqlCommand(query, conn);

            comm.Parameters.AddWithValue("@ID", ID);
            comm.Parameters.AddWithValue("@Nombre", Nombre);
            comm.Parameters.AddWithValue("@Apellido", Apellido);
            comm.Parameters.AddWithValue("@Fecha_Nacimiento", Fecha_Nacimiento);
            comm.Parameters.AddWithValue("@Direccion", Direccion);
            comm.Parameters.AddWithValue("@Genero", Genero);
            comm.Parameters.AddWithValue("@Estado_Civil", Estado_Civil);
            comm.Parameters.AddWithValue("@Movil", Movil);
            comm.Parameters.AddWithValue("@Telefono", Telefono);
            comm.Parameters.AddWithValue("@Correo_Electronico", Correo_Electronico);


            try
            {

                conn.Open();
                comm.ExecuteNonQuery();
                Exito = true;
                ;
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }

            return Exito;
        }

        public static bool Eliminar_Registro(String ID)
        {
            bool Exito = false;


            SqlConnection conn = new SqlConnection(ConnectionString);
            string query = "DELETE FROM Personas where ID = @ID";

            SqlCommand comm = new SqlCommand(query, conn);

            comm.Parameters.AddWithValue("@ID", ID);

            try
            {

                conn.Open();
                comm.ExecuteNonQuery();
                Exito = true;

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }

            return Exito;
        }

        public static DataTable Buscar_Registro(String Nombre)
        {
            DataTable dt_ListaPersonas = new DataTable();
            SqlConnection conn = new SqlConnection(ConnectionString);
            string query = "SElECT * from Personas where Nombre = @Nombre";

            SqlCommand comm = new SqlCommand(query, conn);

            comm.Parameters.AddWithValue("@Nombre", Nombre);

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(comm);
                da.Fill(dt_ListaPersonas);

            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }

            return dt_ListaPersonas;
        }
    }
}

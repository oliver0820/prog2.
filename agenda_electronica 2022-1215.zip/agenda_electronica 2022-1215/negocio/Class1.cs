﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace negocio
{

    public class GestorPersonas
    {


        public static DataTable ObtenerListaPersonas()
        {
            DataTable listaPersonas = new DataTable();

            // Aquí llamamos al método de la capa de datos para obtener la lista de personas
            listaPersonas = Datos.Personas.LeerDatos();

            return listaPersonas;
        }

        public static bool GuardarPersona(string nombre, string apellido, string fechaNacimiento, string direccion, string genero, string estadoCivil, string movil, string telefono, string correoElectronico)
        {
            // Aquí puedes incluir la lógica de negocio necesaria antes de guardar la persona en la base de datos
            if (nombre.Trim() == "" || apellido.Trim() == "" || fechaNacimiento.Trim() == "")
            {
                throw new ArgumentException("El nombre, apellido y fecha de nacimiento son campos obligatorios.");
            }

            // Luego, llamamos al método de la capa de datos para guardar la persona
            return Datos.Personas.Guardar_Registro(nombre, apellido, fechaNacimiento, direccion, genero, estadoCivil, movil, telefono, correoElectronico);
        }

        public static bool ActualizarPersona(string id, string nombre, string apellido, string fechaNacimiento, string direccion, string genero, string estadoCivil, string movil, string telefono, string correoElectronico)
        {
            // Aquí puedes incluir la lógica de negocio necesaria antes de actualizar la persona en la base de datos
            if (nombre.Trim() == "" || fechaNacimiento.Trim() == "")
            {
                throw new ArgumentException("El nombre, apellido y fecha de nacimiento son campos obligatorios.");
            }

            // Luego, llamamos al método de la capa de datos para actualizar la persona
            return Datos.Personas.Actualizar_Registro(id, nombre, apellido, fechaNacimiento, direccion, genero, estadoCivil, movil, telefono, correoElectronico);
        }


        public static bool EliminarPersona(string id)
        {
            // Aquí puedes incluir la lógica de negocio necesaria antes de eliminar la persona de la base de datos
            // Por ejemplo, podrías verificar si la persona tiene asociados datos relacionados que deban ser manejados antes de eliminarla

            // Luego, llamamos al método de la capa de datos para eliminar la persona
            return Datos.Personas.Eliminar_Registro(id);
        }


        public static DataTable BuscarPersona(string nombre)
        {
            DataTable dt_ListaPersonas = new DataTable();
            try
            {
                dt_ListaPersonas = Datos.Personas.Buscar_Registro(nombre);
            }
            catch (Exception ex)
            {
                // Manejar cualquier excepción que pueda surgir, como registrarla en un archivo de registro o mostrar un mensaje al usuario
                Console.WriteLine("Error al buscar la persona: " + ex.Message);
                // También podrías relanzar la excepción si prefieres que la capa superior maneje el error
                throw;
            }
            return dt_ListaPersonas;
        }
    }



}

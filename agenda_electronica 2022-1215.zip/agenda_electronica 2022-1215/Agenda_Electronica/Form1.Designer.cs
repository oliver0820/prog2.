﻿namespace Agenda_Electronica
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dg_Personas = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaNacimientoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direccionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.generoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoCivilDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.movilDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correoElectronicoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_Modificar = new System.Windows.Forms.Button();
            this.btn_Eliminar = new System.Windows.Forms.Button();
            this.Buscar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.tb_Correo = new System.Windows.Forms.TextBox();
            this.tb_Telefono = new System.Windows.Forms.TextBox();
            this.tb_Movil = new System.Windows.Forms.TextBox();
            this.tb_Estado = new System.Windows.Forms.TextBox();
            this.tb_Genero = new System.Windows.Forms.TextBox();
            this.tb_Direccion = new System.Windows.Forms.TextBox();
            this.tb_Apellido = new System.Windows.Forms.TextBox();
            this.tb_Nombre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Correo = new System.Windows.Forms.Label();
            this.Teléfono = new System.Windows.Forms.Label();
            this.Móvil = new System.Windows.Forms.Label();
            this.EstadoCivil = new System.Windows.Forms.Label();
            this.Género = new System.Windows.Forms.Label();
            this.Direccion = new System.Windows.Forms.Label();
            this.FechaNacimiento = new System.Windows.Forms.Label();
            this.Apellido = new System.Windows.Forms.Label();
            this.tb_Fecha = new Bunifu.Framework.UI.BunifuDatepicker();
            this.tb_Buscar = new Bunifu.Framework.UI.BunifuTextbox();
            this.agenda_ElectronicaDataSet = new Agenda_Electronica.Agenda_ElectronicaDataSet();
            this.personasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.personasTableAdapter = new Agenda_Electronica.Agenda_ElectronicaDataSetTableAdapters.PersonasTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Personas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agenda_ElectronicaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(285, 318);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 52);
            this.pictureBox1.TabIndex = 55;
            this.pictureBox1.TabStop = false;
            // 
            // dg_Personas
            // 
            this.dg_Personas.AutoGenerateColumns = false;
            this.dg_Personas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Personas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.apellidoDataGridViewTextBoxColumn,
            this.fechaNacimientoDataGridViewTextBoxColumn,
            this.direccionDataGridViewTextBoxColumn,
            this.generoDataGridViewTextBoxColumn,
            this.estadoCivilDataGridViewTextBoxColumn,
            this.movilDataGridViewTextBoxColumn,
            this.telefonoDataGridViewTextBoxColumn,
            this.correoElectronicoDataGridViewTextBoxColumn});
            this.dg_Personas.DataSource = this.personasBindingSource;
            this.dg_Personas.Location = new System.Drawing.Point(-20, 68);
            this.dg_Personas.Name = "dg_Personas";
            this.dg_Personas.Size = new System.Drawing.Size(527, 244);
            this.dg_Personas.TabIndex = 54;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            // 
            // apellidoDataGridViewTextBoxColumn
            // 
            this.apellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.Name = "apellidoDataGridViewTextBoxColumn";
            // 
            // fechaNacimientoDataGridViewTextBoxColumn
            // 
            this.fechaNacimientoDataGridViewTextBoxColumn.DataPropertyName = "Fecha_Nacimiento";
            this.fechaNacimientoDataGridViewTextBoxColumn.HeaderText = "Fecha_Nacimiento";
            this.fechaNacimientoDataGridViewTextBoxColumn.Name = "fechaNacimientoDataGridViewTextBoxColumn";
            // 
            // direccionDataGridViewTextBoxColumn
            // 
            this.direccionDataGridViewTextBoxColumn.DataPropertyName = "Direccion";
            this.direccionDataGridViewTextBoxColumn.HeaderText = "Direccion";
            this.direccionDataGridViewTextBoxColumn.Name = "direccionDataGridViewTextBoxColumn";
            // 
            // generoDataGridViewTextBoxColumn
            // 
            this.generoDataGridViewTextBoxColumn.DataPropertyName = "Genero";
            this.generoDataGridViewTextBoxColumn.HeaderText = "Genero";
            this.generoDataGridViewTextBoxColumn.Name = "generoDataGridViewTextBoxColumn";
            // 
            // estadoCivilDataGridViewTextBoxColumn
            // 
            this.estadoCivilDataGridViewTextBoxColumn.DataPropertyName = "Estado_Civil";
            this.estadoCivilDataGridViewTextBoxColumn.HeaderText = "Estado_Civil";
            this.estadoCivilDataGridViewTextBoxColumn.Name = "estadoCivilDataGridViewTextBoxColumn";
            // 
            // movilDataGridViewTextBoxColumn
            // 
            this.movilDataGridViewTextBoxColumn.DataPropertyName = "Movil";
            this.movilDataGridViewTextBoxColumn.HeaderText = "Movil";
            this.movilDataGridViewTextBoxColumn.Name = "movilDataGridViewTextBoxColumn";
            // 
            // telefonoDataGridViewTextBoxColumn
            // 
            this.telefonoDataGridViewTextBoxColumn.DataPropertyName = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.HeaderText = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.Name = "telefonoDataGridViewTextBoxColumn";
            // 
            // correoElectronicoDataGridViewTextBoxColumn
            // 
            this.correoElectronicoDataGridViewTextBoxColumn.DataPropertyName = "Correo_Electronico";
            this.correoElectronicoDataGridViewTextBoxColumn.HeaderText = "Correo_Electronico";
            this.correoElectronicoDataGridViewTextBoxColumn.Name = "correoElectronicoDataGridViewTextBoxColumn";
            // 
            // btn_Modificar
            // 
            this.btn_Modificar.Location = new System.Drawing.Point(131, 362);
            this.btn_Modificar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Modificar.Name = "btn_Modificar";
            this.btn_Modificar.Size = new System.Drawing.Size(102, 35);
            this.btn_Modificar.TabIndex = 53;
            this.btn_Modificar.Text = "Modificar";
            this.btn_Modificar.UseVisualStyleBackColor = true;
            // 
            // btn_Eliminar
            // 
            this.btn_Eliminar.Location = new System.Drawing.Point(258, 363);
            this.btn_Eliminar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Eliminar.Name = "btn_Eliminar";
            this.btn_Eliminar.Size = new System.Drawing.Size(86, 35);
            this.btn_Eliminar.TabIndex = 52;
            this.btn_Eliminar.Text = "Eliminar";
            this.btn_Eliminar.UseVisualStyleBackColor = true;
            // 
            // Buscar
            // 
            this.Buscar.Location = new System.Drawing.Point(361, 363);
            this.Buscar.Margin = new System.Windows.Forms.Padding(2);
            this.Buscar.Name = "Buscar";
            this.Buscar.Size = new System.Drawing.Size(110, 36);
            this.Buscar.TabIndex = 51;
            this.Buscar.Text = "Buscar";
            this.Buscar.UseVisualStyleBackColor = true;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Location = new System.Drawing.Point(-4, 363);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(112, 35);
            this.btn_Guardar.TabIndex = 50;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // tb_Correo
            // 
            this.tb_Correo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Correo.Location = new System.Drawing.Point(641, 371);
            this.tb_Correo.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Correo.Name = "tb_Correo";
            this.tb_Correo.Size = new System.Drawing.Size(179, 29);
            this.tb_Correo.TabIndex = 49;
            // 
            // tb_Telefono
            // 
            this.tb_Telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Telefono.Location = new System.Drawing.Point(641, 325);
            this.tb_Telefono.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Telefono.Name = "tb_Telefono";
            this.tb_Telefono.Size = new System.Drawing.Size(179, 29);
            this.tb_Telefono.TabIndex = 48;
            // 
            // tb_Movil
            // 
            this.tb_Movil.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Movil.Location = new System.Drawing.Point(641, 283);
            this.tb_Movil.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Movil.Name = "tb_Movil";
            this.tb_Movil.Size = new System.Drawing.Size(179, 29);
            this.tb_Movil.TabIndex = 47;
            // 
            // tb_Estado
            // 
            this.tb_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Estado.Location = new System.Drawing.Point(641, 247);
            this.tb_Estado.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Estado.Name = "tb_Estado";
            this.tb_Estado.Size = new System.Drawing.Size(179, 29);
            this.tb_Estado.TabIndex = 46;
            // 
            // tb_Genero
            // 
            this.tb_Genero.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Genero.Location = new System.Drawing.Point(641, 208);
            this.tb_Genero.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Genero.Name = "tb_Genero";
            this.tb_Genero.Size = new System.Drawing.Size(179, 29);
            this.tb_Genero.TabIndex = 45;
            // 
            // tb_Direccion
            // 
            this.tb_Direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Direccion.Location = new System.Drawing.Point(641, 167);
            this.tb_Direccion.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Direccion.Name = "tb_Direccion";
            this.tb_Direccion.Size = new System.Drawing.Size(179, 29);
            this.tb_Direccion.TabIndex = 44;
            // 
            // tb_Apellido
            // 
            this.tb_Apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Apellido.Location = new System.Drawing.Point(641, 88);
            this.tb_Apellido.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Apellido.Name = "tb_Apellido";
            this.tb_Apellido.Size = new System.Drawing.Size(179, 29);
            this.tb_Apellido.TabIndex = 43;
            // 
            // tb_Nombre
            // 
            this.tb_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tb_Nombre.Location = new System.Drawing.Point(641, 50);
            this.tb_Nombre.Margin = new System.Windows.Forms.Padding(2);
            this.tb_Nombre.Name = "tb_Nombre";
            this.tb_Nombre.Size = new System.Drawing.Size(179, 29);
            this.tb_Nombre.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-9, 324);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 27);
            this.label1.TabIndex = 41;
            this.label1.Text = "Buscar:";
            // 
            // Correo
            // 
            this.Correo.AutoSize = true;
            this.Correo.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Correo.Location = new System.Drawing.Point(532, 372);
            this.Correo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Correo.Name = "Correo";
            this.Correo.Size = new System.Drawing.Size(85, 27);
            this.Correo.TabIndex = 40;
            this.Correo.Text = "EMAIL:";
            // 
            // Teléfono
            // 
            this.Teléfono.AutoSize = true;
            this.Teléfono.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Teléfono.Location = new System.Drawing.Point(518, 329);
            this.Teléfono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Teléfono.Name = "Teléfono";
            this.Teléfono.Size = new System.Drawing.Size(109, 27);
            this.Teléfono.TabIndex = 39;
            this.Teléfono.Text = "Teléfono:";
            // 
            // Móvil
            // 
            this.Móvil.AutoSize = true;
            this.Móvil.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Móvil.Location = new System.Drawing.Point(545, 287);
            this.Móvil.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Móvil.Name = "Móvil";
            this.Móvil.Size = new System.Drawing.Size(73, 27);
            this.Móvil.TabIndex = 38;
            this.Móvil.Text = "Móvil:";
            // 
            // EstadoCivil
            // 
            this.EstadoCivil.AutoSize = true;
            this.EstadoCivil.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EstadoCivil.Location = new System.Drawing.Point(509, 247);
            this.EstadoCivil.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.EstadoCivil.Name = "EstadoCivil";
            this.EstadoCivil.Size = new System.Drawing.Size(142, 27);
            this.EstadoCivil.TabIndex = 37;
            this.EstadoCivil.Text = "Estado Civil:";
            // 
            // Género
            // 
            this.Género.AutoSize = true;
            this.Género.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Género.Location = new System.Drawing.Point(532, 212);
            this.Género.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Género.Name = "Género";
            this.Género.Size = new System.Drawing.Size(94, 27);
            this.Género.TabIndex = 36;
            this.Género.Text = "Género:";
            // 
            // Direccion
            // 
            this.Direccion.AutoSize = true;
            this.Direccion.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Direccion.Location = new System.Drawing.Point(533, 171);
            this.Direccion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Direccion.Name = "Direccion";
            this.Direccion.Size = new System.Drawing.Size(118, 27);
            this.Direccion.TabIndex = 35;
            this.Direccion.Text = "Dirección:";
            // 
            // FechaNacimiento
            // 
            this.FechaNacimiento.AutoSize = true;
            this.FechaNacimiento.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FechaNacimiento.Location = new System.Drawing.Point(518, 129);
            this.FechaNacimiento.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FechaNacimiento.Name = "FechaNacimiento";
            this.FechaNacimiento.Size = new System.Drawing.Size(136, 27);
            this.FechaNacimiento.TabIndex = 34;
            this.FechaNacimiento.Text = "Fecha Nac: ";
            // 
            // Apellido
            // 
            this.Apellido.AutoSize = true;
            this.Apellido.Font = new System.Drawing.Font("Arial Black", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apellido.Location = new System.Drawing.Point(524, 89);
            this.Apellido.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Apellido.Name = "Apellido";
            this.Apellido.Size = new System.Drawing.Size(103, 27);
            this.Apellido.TabIndex = 33;
            this.Apellido.Text = "Apellido:";
            // 
            // tb_Fecha
            // 
            this.tb_Fecha.BackColor = System.Drawing.Color.SeaGreen;
            this.tb_Fecha.BorderRadius = 0;
            this.tb_Fecha.ForeColor = System.Drawing.Color.White;
            this.tb_Fecha.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.tb_Fecha.FormatCustom = null;
            this.tb_Fecha.Location = new System.Drawing.Point(641, 129);
            this.tb_Fecha.Name = "tb_Fecha";
            this.tb_Fecha.Size = new System.Drawing.Size(322, 36);
            this.tb_Fecha.TabIndex = 56;
            this.tb_Fecha.Value = new System.DateTime(2024, 4, 1, 14, 49, 58, 374);
            // 
            // tb_Buscar
            // 
            this.tb_Buscar.BackColor = System.Drawing.Color.Silver;
            this.tb_Buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tb_Buscar.BackgroundImage")));
            this.tb_Buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tb_Buscar.ForeColor = System.Drawing.Color.SeaGreen;
            this.tb_Buscar.Icon = ((System.Drawing.Image)(resources.GetObject("tb_Buscar.Icon")));
            this.tb_Buscar.Location = new System.Drawing.Point(-4, 318);
            this.tb_Buscar.Name = "tb_Buscar";
            this.tb_Buscar.Size = new System.Drawing.Size(250, 42);
            this.tb_Buscar.TabIndex = 57;
            this.tb_Buscar.text = "Bunifu TextBox";
            // 
            // agenda_ElectronicaDataSet
            // 
            this.agenda_ElectronicaDataSet.DataSetName = "Agenda_ElectronicaDataSet";
            this.agenda_ElectronicaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // personasBindingSource
            // 
            this.personasBindingSource.DataMember = "Personas";
            this.personasBindingSource.DataSource = this.agenda_ElectronicaDataSet;
            // 
            // personasTableAdapter
            // 
            this.personasTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb_Buscar);
            this.Controls.Add(this.tb_Fecha);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dg_Personas);
            this.Controls.Add(this.btn_Modificar);
            this.Controls.Add(this.btn_Eliminar);
            this.Controls.Add(this.Buscar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.tb_Correo);
            this.Controls.Add(this.tb_Telefono);
            this.Controls.Add(this.tb_Movil);
            this.Controls.Add(this.tb_Estado);
            this.Controls.Add(this.tb_Genero);
            this.Controls.Add(this.tb_Direccion);
            this.Controls.Add(this.tb_Apellido);
            this.Controls.Add(this.tb_Nombre);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Correo);
            this.Controls.Add(this.Teléfono);
            this.Controls.Add(this.Móvil);
            this.Controls.Add(this.EstadoCivil);
            this.Controls.Add(this.Género);
            this.Controls.Add(this.Direccion);
            this.Controls.Add(this.FechaNacimiento);
            this.Controls.Add(this.Apellido);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Personas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agenda_ElectronicaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personasBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dg_Personas;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaNacimientoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn direccionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn generoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoCivilDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn movilDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn correoElectronicoDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_Modificar;
        private System.Windows.Forms.Button btn_Eliminar;
        private System.Windows.Forms.Button Buscar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.TextBox tb_Correo;
        private System.Windows.Forms.TextBox tb_Telefono;
        private System.Windows.Forms.TextBox tb_Movil;
        private System.Windows.Forms.TextBox tb_Estado;
        private System.Windows.Forms.TextBox tb_Genero;
        private System.Windows.Forms.TextBox tb_Direccion;
        private System.Windows.Forms.TextBox tb_Apellido;
        private System.Windows.Forms.TextBox tb_Nombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Correo;
        private System.Windows.Forms.Label Teléfono;
        private System.Windows.Forms.Label Móvil;
        private System.Windows.Forms.Label EstadoCivil;
        private System.Windows.Forms.Label Género;
        private System.Windows.Forms.Label Direccion;
        private System.Windows.Forms.Label FechaNacimiento;
        private System.Windows.Forms.Label Apellido;
        private Bunifu.Framework.UI.BunifuDatepicker tb_Fecha;
        private Bunifu.Framework.UI.BunifuTextbox tb_Buscar;
        private Agenda_ElectronicaDataSet agenda_ElectronicaDataSet;
        private System.Windows.Forms.BindingSource personasBindingSource;
        private Agenda_ElectronicaDataSetTableAdapters.PersonasTableAdapter personasTableAdapter;
    }
}

